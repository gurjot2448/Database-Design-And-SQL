MariaDB [(none)]> create csd2204;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'csd2204' at line 1
MariaDB [(none)]> create csd2204;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'csd2204' at line 1
MariaDB [(none)]> show databses;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'databses' at line 1
MariaDB [(none)]> use csd2204s18;
Database changed
MariaDB [csd2204s18]> show tables;
+----------------------+
| Tables_in_csd2204s18 |
+----------------------+
| c1                   |
| c3                   |
| countries            |
| customer             |
| departments          |
| employees            |
| g1                   |
| h1                   |
| j1                   |
| j2                   |
| job_history          |
| jobs                 |
| locations            |
| manu                 |
| movie                |
| orders               |
| p1                   |
| persons              |
| products             |
| regions              |
| v2                   |
| v3                   |
| v4                   |
+----------------------+
23 rows in set (0.00 sec)

MariaDB [csd2204s18]> CREATE TABLE Client (
    ->   AccountNumber INTEGER PRIMARY KEY,
    ->   Name          VARCHAR(255) NOT NULL
    -> );
Query OK, 0 rows affected (0.25 sec)

MariaDB [csd2204s18]> 
MariaDB [csd2204s18]> INSERT INTO Client VALUES(1, 'Zapp Brannigan');
Query OK, 1 row affected (0.02 sec)

MariaDB [csd2204s18]> INSERT INTO Client VALUES(2, "Al Gore's Head");
Query OK, 1 row affected (0.02 sec)

MariaDB [csd2204s18]> INSERT INTO Client VALUES(3, 'Barbados Slim');
Query OK, 1 row affected (0.06 sec)

MariaDB [csd2204s18]> INSERT INTO Client VALUES(4, 'Ogden Wernstrom');
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> INSERT INTO Client VALUES(5, 'Leo Wong');
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> INSERT INTO Client VALUES(6, 'Lrrr');
Query OK, 1 row affected (0.01 sec)

MariaDB [csd2204s18]> INSERT INTO Client VALUES(7, 'John Zoidberg');
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> INSERT INTO Client VALUES(8, 'John Zoidfarb');
Query OK, 1 row affected (0.02 sec)

MariaDB [csd2204s18]> INSERT INTO Client VALUES(9, 'Morbo');
Query OK, 1 row affected (0.02 sec)

MariaDB [csd2204s18]> INSERT INTO Client VALUES(10, 'Judge John Whitey');
Query OK, 1 row affected (0.01 sec)

MariaDB [csd2204s18]> INSERT INTO Client VALUES(11, 'Calculon');
Query OK, 1 row affected (0.01 sec)

MariaDB [csd2204s18]> 
MariaDB [csd2204s18]> CREATE TABLE Employee (
    ->   EmployeeID  INTEGER PRIMARY KEY,
    ->   Name        VARCHAR(255) NOT NULL,
    ->   Position    VARCHAR(255) NOT NULL,
    ->   Salary      REAL NOT NULL,
    ->   Remarks     VARCHAR(255)
    -> ); 
Query OK, 0 rows affected (0.23 sec)

MariaDB [csd2204s18]> 
MariaDB [csd2204s18]> INSERT INTO Employee VALUES(1, 'Phillip J. Fry', 'Delivery boy', 7500.0, 'Not to be confused with the Philip J. Fry from Hovering Squid World 97a');
Query OK, 1 row affected (0.01 sec)

MariaDB [csd2204s18]> INSERT INTO Employee VALUES(2, 'Turanga Leela', 'Captain', 10000.0, NULL);
Query OK, 1 row affected (0.01 sec)

MariaDB [csd2204s18]> INSERT INTO Employee VALUES(3, 'Bender Bending Rodriguez', 'Robot', 7500.0, NULL);
Query OK, 1 row affected (0.02 sec)

MariaDB [csd2204s18]> INSERT INTO Employee VALUES(4, 'Hubert J. Farnsworth', 'CEO', 20000.0, NULL);
Query OK, 1 row affected (0.02 sec)

MariaDB [csd2204s18]> INSERT INTO Employee VALUES(5, 'John A. Zoidberg', 'Physician', 25.0, NULL);
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> INSERT INTO Employee VALUES(6, 'Amy Wong', 'Intern', 5000.0, NULL);
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> INSERT INTO Employee VALUES(7, 'Hermes Conrad', 'Bureaucrat', 10000.0, NULL);
Query OK, 1 row affected (0.02 sec)

MariaDB [csd2204s18]> INSERT INTO Employee VALUES(8, 'Scruffy Scruffington', 'Janitor', 5000.0, NULL);
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> 
MariaDB [csd2204s18]> CREATE TABLE Planet (
    ->   PlanetID    INTEGER PRIMARY KEY,
    ->   Name        VARCHAR(255) NOT NULL,
    ->   Coordinates REAL NOT NULL
    -> ); 
Query OK, 0 rows affected (0.25 sec)

MariaDB [csd2204s18]> 
MariaDB [csd2204s18]> INSERT INTO Planet VALUES(1, 'Omicron Persei 8', 89475345.3545);
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> INSERT INTO Planet VALUES(2, 'Decapod X', 65498463216.3466);
Query OK, 1 row affected (0.06 sec)

MariaDB [csd2204s18]> INSERT INTO Planet VALUES(3, 'Mars', 32435021.65468);
Query OK, 1 row affected (0.11 sec)

MariaDB [csd2204s18]> INSERT INTO Planet VALUES(4, 'Omega III', 98432121.5464);
Query OK, 1 row affected (0.05 sec)

MariaDB [csd2204s18]> INSERT INTO Planet VALUES(5, 'Tarantulon VI', 849842198.354654);
Query OK, 1 row affected (0.02 sec)

MariaDB [csd2204s18]> INSERT INTO Planet VALUES(6, 'Cannibalon', 654321987.21654);
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> INSERT INTO Planet VALUES(7, 'DogDoo VII', 65498721354.688);
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> INSERT INTO Planet VALUES(8, 'Nintenduu 64', 6543219894.1654);
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> INSERT INTO Planet VALUES(9, 'Amazonia', 65432135979.6547);
Query OK, 1 row affected (0.01 sec)

MariaDB [csd2204s18]> 
MariaDB [csd2204s18]> CREATE TABLE Has_Clearance (
    ->   Employee  INTEGER NOT NULL,
    ->   Planet    INTEGER NOT NULL,
    ->   Level     INTEGER NOT NULL,
    ->   PRIMARY KEY(Employee, Planet),
    ->   FOREIGN KEY (Employee) REFERENCES Employee(EmployeeID),
    ->   FOREIGN KEY (Planet) REFERENCES Planet(PlanetID)
    -> ); 
Query OK, 0 rows affected (0.31 sec)

MariaDB [csd2204s18]> 
MariaDB [csd2204s18]> INSERT INTO Has_Clearance VALUES(1, 1, 2);
Query OK, 1 row affected (0.05 sec)

MariaDB [csd2204s18]> INSERT INTO Has_Clearance VALUES(1, 2, 3);
Query OK, 1 row affected (0.08 sec)

MariaDB [csd2204s18]> INSERT INTO Has_Clearance VALUES(2, 3, 2);
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> INSERT INTO Has_Clearance VALUES(2, 4, 4);
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> INSERT INTO Has_Clearance VALUES(3, 5, 2);
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> INSERT INTO Has_Clearance VALUES(3, 6, 4);
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> INSERT INTO Has_Clearance VALUES(4, 7, 1);
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> 
MariaDB [csd2204s18]> CREATE TABLE Shipment (
    ->   ShipmentID    INTEGER PRIMARY KEY,
    ->   ShipmentDate  DATE,
    ->   Manager       INTEGER NOT NULL,
    ->   Planet        INTEGER NOT NULL,
    ->   FOREIGN KEY (Manager) REFERENCES Employee(EmployeeID),
    ->   FOREIGN KEY (Planet) REFERENCES Planet(PlanetID)
    -> );
Query OK, 0 rows affected (0.27 sec)

MariaDB [csd2204s18]> 
MariaDB [csd2204s18]> INSERT INTO Shipment VALUES(1, '3004/05/11', 1, 1);
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> INSERT INTO Shipment VALUES(2, '3004/05/11', 1, 2);
Query OK, 1 row affected (0.02 sec)

MariaDB [csd2204s18]> INSERT INTO Shipment VALUES(3, NULL, 2, 3);
Query OK, 1 row affected (0.05 sec)

MariaDB [csd2204s18]> INSERT INTO Shipment VALUES(4, NULL, 2, 4);
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> INSERT INTO Shipment VALUES(5, NULL, 7, 5);
Query OK, 1 row affected (0.03 sec)

MariaDB [csd2204s18]> 
MariaDB [csd2204s18]> CREATE TABLE Package (
    ->   Shipment      INTEGER NOT NULL,
    ->   PackageNumber INTEGER NOT NULL,
    ->   Contents      VARCHAR(255) NOT NULL,
    ->   Weight        REAL NOT NULL,
    ->   Sender        INTEGER NOT NULL,
    ->   Recipient     INTEGER NOT NULL,
    ->   PRIMARY KEY(Shipment, PackageNumber),
    ->   FOREIGN KEY (Shipment) REFERENCES Shipment(ShipmentID),
    ->   FOREIGN KEY (Sender) REFERENCES Client(AccountNumber),
    ->   FOREIGN KEY (Recipient) REFERENCES Client(AccountNumber)
    -> );
Query OK, 0 rows affected (0.30 sec)

MariaDB [csd2204s18]> 
MariaDB [csd2204s18]> INSERT INTO Package VALUES(1, 1, 'Undeclared', 1.5, 1, 2);
Query OK, 1 row affected (0.05 sec)

MariaDB [csd2204s18]> INSERT INTO Package VALUES(2, 1, 'Undeclared', 10.0, 2, 3);
Query OK, 1 row affected (0.01 sec)

MariaDB [csd2204s18]> INSERT INTO Package VALUES(2, 2, 'A bucket of krill', 2.0, 8, 7);
Query OK, 1 row affected (0.06 sec)

MariaDB [csd2204s18]> INSERT INTO Package VALUES(3, 1, 'Undeclared', 15.0, 3, 4);
Query OK, 1 row affected (0.02 sec)

MariaDB [csd2204s18]> INSERT INTO Package VALUES(3, 2, 'Undeclared', 3.0, 5, 1);
Query OK, 1 row affected (0.01 sec)

MariaDB [csd2204s18]> INSERT INTO Package VALUES(3, 3, 'Undeclared', 7.0, 2, 3);
Query OK, 1 row affected (0.01 sec)

MariaDB [csd2204s18]> INSERT INTO Package VALUES(4, 1, 'Undeclared', 5.0, 4, 5);
Query OK, 1 row affected (0.02 sec)

MariaDB [csd2204s18]> INSERT INTO Package VALUES(4, 2, 'Undeclared', 27.0, 1, 2);
Query OK, 1 row affected (0.02 sec)

MariaDB [csd2204s18]> INSERT INTO Package VALUES(5, 1, 'Undeclared', 100.0, 5, 1);
Query OK, 1 row affected (0.09 sec)

MariaDB [csd2204s18]> show tables;
+----------------------+
| Tables_in_csd2204s18 |
+----------------------+
| c1                   |
| c3                   |
| client               |
| countries            |
| customer             |
| departments          |
| employee             |
| employees            |
| g1                   |
| h1                   |
| has_clearance        |
| j1                   |
| j2                   |
| job_history          |
| jobs                 |
| locations            |
| manu                 |
| movie                |
| orders               |
| p1                   |
| package              |
| persons              |
| planet               |
| products             |
| regions              |
| shipment             |
| v2                   |
| v3                   |
| v4                   |
+----------------------+
29 rows in set (0.00 sec)

MariaDB [csd2204s18]> drop c1;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'c1' at line 1
MariaDB [csd2204s18]> drop view c1;
ERROR 1347 (HY000): 'csd2204s18.c1' is not VIEW
MariaDB [csd2204s18]> drop table c1;
Query OK, 0 rows affected (0.22 sec)

MariaDB [csd2204s18]> drop table c3;
Query OK, 0 rows affected (0.17 sec)

MariaDB [csd2204s18]> drop view g1;
ERROR 1347 (HY000): 'csd2204s18.g1' is not VIEW
MariaDB [csd2204s18]> drop table g1;
Query OK, 0 rows affected (0.23 sec)

MariaDB [csd2204s18]> drop table h1;
ERROR 1965 (42S02): 'csd2204s18.h1' is a view
MariaDB [csd2204s18]> drop view h1;
Query OK, 0 rows affected (0.01 sec)

MariaDB [csd2204s18]> drop view j1,j2,p1;
ERROR 1347 (HY000): 'csd2204s18.p1' is not VIEW
MariaDB [csd2204s18]> drop view j1,j2;
ERROR 1051 (42S02): Unknown table 'csd2204s18.j1,csd2204s18.j2'
MariaDB [csd2204s18]> drop table p1;
Query OK, 0 rows affected (0.22 sec)

MariaDB [csd2204s18]> drop table j1,j2;
ERROR 1051 (42S02): Unknown table 'csd2204s18.j1,csd2204s18.j2'
MariaDB [csd2204s18]> drop view j1;
ERROR 1051 (42S02): Unknown table 'csd2204s18.j1'
MariaDB [csd2204s18]> drop table j1;
ERROR 1051 (42S02): Unknown table 'csd2204s18.j1'
MariaDB [csd2204s18]> show tables;
+----------------------+
| Tables_in_csd2204s18 |
+----------------------+
| client               |
| countries            |
| customer             |
| departments          |
| employee             |
| employees            |
| has_clearance        |
| job_history          |
| jobs                 |
| locations            |
| manu                 |
| movie                |
| orders               |
| package              |
| persons              |
| planet               |
| products             |
| regions              |
| shipment             |
| v2                   |
| v3                   |
| v4                   |
+----------------------+
22 rows in set (0.00 sec)

MariaDB [csd2204s18]> drop view j1,j2,j3;
ERROR 1051 (42S02): Unknown table 'csd2204s18.j1,csd2204s18.j2,csd2204s18.j3'
MariaDB [csd2204s18]> drop view v2;
Query OK, 0 rows affected (0.03 sec)

MariaDB [csd2204s18]> drop view v3,v4;
Query OK, 0 rows affected (0.03 sec)

MariaDB [csd2204s18]> show tables;
+----------------------+
| Tables_in_csd2204s18 |
+----------------------+
| client               |
| countries            |
| customer             |
| departments          |
| employee             |
| employees            |
| has_clearance        |
| job_history          |
| jobs                 |
| locations            |
| manu                 |
| movie                |
| orders               |
| package              |
| persons              |
| planet               |
| products             |
| regions              |
| shipment             |
+----------------------+
19 rows in set (0.00 sec)

MariaDB [csd2204s18]> desc employee;
+------------+--------------+------+-----+---------+-------+
| Field      | Type         | Null | Key | Default | Extra |
+------------+--------------+------+-----+---------+-------+
| EmployeeID | int(11)      | NO   | PRI | NULL    |       |
| Name       | varchar(255) | NO   |     | NULL    |       |
| Position   | varchar(255) | NO   |     | NULL    |       |
| Salary     | double       | NO   |     | NULL    |       |
| Remarks    | varchar(255) | YES  |     | NULL    |       |
+------------+--------------+------+-----+---------+-------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> desc client;
+---------------+--------------+------+-----+---------+-------+
| Field         | Type         | Null | Key | Default | Extra |
+---------------+--------------+------+-----+---------+-------+
| AccountNumber | int(11)      | NO   | PRI | NULL    |       |
| Name          | varchar(255) | NO   |     | NULL    |       |
+---------------+--------------+------+-----+---------+-------+
2 rows in set (0.00 sec)

MariaDB [csd2204s18]> desc has_clearance;
+----------+---------+------+-----+---------+-------+
| Field    | Type    | Null | Key | Default | Extra |
+----------+---------+------+-----+---------+-------+
| Employee | int(11) | NO   | PRI | NULL    |       |
| Planet   | int(11) | NO   | PRI | NULL    |       |
| Level    | int(11) | NO   |     | NULL    |       |
+----------+---------+------+-----+---------+-------+
3 rows in set (0.00 sec)

MariaDB [csd2204s18]> desc planets;
ERROR 1146 (42S02): Table 'csd2204s18.planets' doesn't exist
MariaDB [csd2204s18]> desc planet;
+-------------+--------------+------+-----+---------+-------+
| Field       | Type         | Null | Key | Default | Extra |
+-------------+--------------+------+-----+---------+-------+
| PlanetID    | int(11)      | NO   | PRI | NULL    |       |
| Name        | varchar(255) | NO   |     | NULL    |       |
| Coordinates | double       | NO   |     | NULL    |       |
+-------------+--------------+------+-----+---------+-------+
3 rows in set (0.00 sec)

MariaDB [csd2204s18]> desc shipment;
+--------------+---------+------+-----+---------+-------+
| Field        | Type    | Null | Key | Default | Extra |
+--------------+---------+------+-----+---------+-------+
| ShipmentID   | int(11) | NO   | PRI | NULL    |       |
| ShipmentDate | date    | YES  |     | NULL    |       |
| Manager      | int(11) | NO   | MUL | NULL    |       |
| Planet       | int(11) | NO   | MUL | NULL    |       |
+--------------+---------+------+-----+---------+-------+
4 rows in set (0.00 sec)

MariaDB [csd2204s18]> desc package;
+---------------+--------------+------+-----+---------+-------+
| Field         | Type         | Null | Key | Default | Extra |
+---------------+--------------+------+-----+---------+-------+
| Shipment      | int(11)      | NO   | PRI | NULL    |       |
| PackageNumber | int(11)      | NO   | PRI | NULL    |       |
| Contents      | varchar(255) | NO   |     | NULL    |       |
| Weight        | double       | NO   |     | NULL    |       |
| Sender        | int(11)      | NO   | MUL | NULL    |       |
| Recipient     | int(11)      | NO   | MUL | NULL    |       |
+---------------+--------------+------+-----+---------+-------+
6 rows in set (0.00 sec)

MariaDB [csd2204s18]> selct * from employee;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'selct * from employee' at line 1
MariaDB [csd2204s18]> select * from employee;
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
| EmployeeID | Name                     | Position     | Salary | Remarks                                                                 |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
|          1 | Phillip J. Fry           | Delivery boy |   7500 | Not to be confused with the Philip J. Fry from Hovering Squid World 97a |
|          2 | Turanga Leela            | Captain      |  10000 | NULL                                                                    |
|          3 | Bender Bending Rodriguez | Robot        |   7500 | NULL                                                                    |
|          4 | Hubert J. Farnsworth     | CEO          |  20000 | NULL                                                                    |
|          5 | John A. Zoidberg         | Physician    |     25 | NULL                                                                    |
|          6 | Amy Wong                 | Intern       |   5000 | NULL                                                                    |
|          7 | Hermes Conrad            | Bureaucrat   |  10000 | NULL                                                                    |
|          8 | Scruffy Scruffington     | Janitor      |   5000 | NULL                                                                    |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
8 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from client;
+---------------+-------------------+
| AccountNumber | Name              |
+---------------+-------------------+
|             1 | Zapp Brannigan    |
|             2 | Al Gore's Head    |
|             3 | Barbados Slim     |
|             4 | Ogden Wernstrom   |
|             5 | Leo Wong          |
|             6 | Lrrr              |
|             7 | John Zoidberg     |
|             8 | John Zoidfarb     |
|             9 | Morbo             |
|            10 | Judge John Whitey |
|            11 | Calculon          |
+---------------+-------------------+
11 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from has_clearance;;
+----------+--------+-------+
| Employee | Planet | Level |
+----------+--------+-------+
|        1 |      1 |     2 |
|        1 |      2 |     3 |
|        2 |      3 |     2 |
|        2 |      4 |     4 |
|        3 |      5 |     2 |
|        3 |      6 |     4 |
|        4 |      7 |     1 |
+----------+--------+-------+
7 rows in set (0.00 sec)

ERROR: No query specified

MariaDB [csd2204s18]> select * from planets;
ERROR 1146 (42S02): Table 'csd2204s18.planets' doesn't exist
MariaDB [csd2204s18]> select * from planet;
+----------+------------------+------------------+
| PlanetID | Name             | Coordinates      |
+----------+------------------+------------------+
|        1 | Omicron Persei 8 |    89475345.3545 |
|        2 | Decapod X        | 65498463216.3466 |
|        3 | Mars             |   32435021.65468 |
|        4 | Omega III        |    98432121.5464 |
|        5 | Tarantulon VI    | 849842198.354654 |
|        6 | Cannibalon       |  654321987.21654 |
|        7 | DogDoo VII       |  65498721354.688 |
|        8 | Nintenduu 64     |  6543219894.1654 |
|        9 | Amazonia         | 65432135979.6547 |
+----------+------------------+------------------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from shipment;
+------------+--------------+---------+--------+
| ShipmentID | ShipmentDate | Manager | Planet |
+------------+--------------+---------+--------+
|          1 | 3004-05-11   |       1 |      1 |
|          2 | 3004-05-11   |       1 |      2 |
|          3 | NULL         |       2 |      3 |
|          4 | NULL         |       2 |      4 |
|          5 | NULL         |       7 |      5 |
+------------+--------------+---------+--------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from package;
+----------+---------------+-------------------+--------+--------+-----------+
| Shipment | PackageNumber | Contents          | Weight | Sender | Recipient |
+----------+---------------+-------------------+--------+--------+-----------+
|        1 |             1 | Undeclared        |    1.5 |      1 |         2 |
|        2 |             1 | Undeclared        |     10 |      2 |         3 |
|        2 |             2 | A bucket of krill |      2 |      8 |         7 |
|        3 |             1 | Undeclared        |     15 |      3 |         4 |
|        3 |             2 | Undeclared        |      3 |      5 |         1 |
|        3 |             3 | Undeclared        |      7 |      2 |         3 |
|        4 |             1 | Undeclared        |      5 |      4 |         5 |
|        4 |             2 | Undeclared        |     27 |      1 |         2 |
|        5 |             1 | Undeclared        |    100 |      5 |         1 |
+----------+---------------+-------------------+--------+--------+-----------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from employee;
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
| EmployeeID | Name                     | Position     | Salary | Remarks                                                                 |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
|          1 | Phillip J. Fry           | Delivery boy |   7500 | Not to be confused with the Philip J. Fry from Hovering Squid World 97a |
|          2 | Turanga Leela            | Captain      |  10000 | NULL                                                                    |
|          3 | Bender Bending Rodriguez | Robot        |   7500 | NULL                                                                    |
|          4 | Hubert J. Farnsworth     | CEO          |  20000 | NULL                                                                    |
|          5 | John A. Zoidberg         | Physician    |     25 | NULL                                                                    |
|          6 | Amy Wong                 | Intern       |   5000 | NULL                                                                    |
|          7 | Hermes Conrad            | Bureaucrat   |  10000 | NULL                                                                    |
|          8 | Scruffy Scruffington     | Janitor      |   5000 | NULL                                                                    |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
8 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from shipment;
+------------+--------------+---------+--------+
| ShipmentID | ShipmentDate | Manager | Planet |
+------------+--------------+---------+--------+
|          1 | 3004-05-11   |       1 |      1 |
|          2 | 3004-05-11   |       1 |      2 |
|          3 | NULL         |       2 |      3 |
|          4 | NULL         |       2 |      4 |
|          5 | NULL         |       7 |      5 |
+------------+--------------+---------+--------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> select employee.name,shipment.shipmentDate,shipment.manager,shipment.planet from shipment inner join employee on shipment.shipment_id = employee.employee_id;
ERROR 1054 (42S22): Unknown column 'shipment.shipment_id' in 'on clause'
MariaDB [csd2204s18]> select employee.name,shipment.shipmentDate,shipment.manager,shipment.planet from shipment inner join employee on shipment.shipmentid = employee.employeeid;
+--------------------------+--------------+---------+--------+
| name                     | shipmentDate | manager | planet |
+--------------------------+--------------+---------+--------+
| Phillip J. Fry           | 3004-05-11   |       1 |      1 |
| Turanga Leela            | 3004-05-11   |       1 |      2 |
| Bender Bending Rodriguez | NULL         |       2 |      3 |
| Hubert J. Farnsworth     | NULL         |       2 |      4 |
| John A. Zoidberg         | NULL         |       7 |      5 |
+--------------------------+--------------+---------+--------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> select employee.name,shipment.shipmentDate,shipment.manager,shipment.planet from shipment inner join employee on shipment.shipmentid = employee.employeeid where planet = 2;
+---------------+--------------+---------+--------+
| name          | shipmentDate | manager | planet |
+---------------+--------------+---------+--------+
| Turanga Leela | 3004-05-11   |       1 |      2 |
+---------------+--------------+---------+--------+
1 row in set (0.00 sec)

MariaDB [csd2204s18]> create or replace view s as select employee.name,shipment.shipmentDate,shipment.manager,shipment.planet from shipment inner join employee on shipment.shipmentid = employee.employeeid where planet = 2;
Query OK, 0 rows affected (0.06 sec)

MariaDB [csd2204s18]> select * from s;
+---------------+--------------+---------+--------+
| name          | shipmentDate | manager | planet |
+---------------+--------------+---------+--------+
| Turanga Leela | 3004-05-11   |       1 |      2 |
+---------------+--------------+---------+--------+
1 row in set (0.00 sec)

MariaDB [csd2204s18]> select * from client;
+---------------+-------------------+
| AccountNumber | Name              |
+---------------+-------------------+
|             1 | Zapp Brannigan    |
|             2 | Al Gore's Head    |
|             3 | Barbados Slim     |
|             4 | Ogden Wernstrom   |
|             5 | Leo Wong          |
|             6 | Lrrr              |
|             7 | John Zoidberg     |
|             8 | John Zoidfarb     |
|             9 | Morbo             |
|            10 | Judge John Whitey |
|            11 | Calculon          |
+---------------+-------------------+
11 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from package;
+----------+---------------+-------------------+--------+--------+-----------+
| Shipment | PackageNumber | Contents          | Weight | Sender | Recipient |
+----------+---------------+-------------------+--------+--------+-----------+
|        1 |             1 | Undeclared        |    1.5 |      1 |         2 |
|        2 |             1 | Undeclared        |     10 |      2 |         3 |
|        2 |             2 | A bucket of krill |      2 |      8 |         7 |
|        3 |             1 | Undeclared        |     15 |      3 |         4 |
|        3 |             2 | Undeclared        |      3 |      5 |         1 |
|        3 |             3 | Undeclared        |      7 |      2 |         3 |
|        4 |             1 | Undeclared        |      5 |      4 |         5 |
|        4 |             2 | Undeclared        |     27 |      1 |         2 |
|        5 |             1 | Undeclared        |    100 |      5 |         1 |
+----------+---------------+-------------------+--------+--------+-----------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from employee;
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
| EmployeeID | Name                     | Position     | Salary | Remarks                                                                 |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
|          1 | Phillip J. Fry           | Delivery boy |   7500 | Not to be confused with the Philip J. Fry from Hovering Squid World 97a |
|          2 | Turanga Leela            | Captain      |  10000 | NULL                                                                    |
|          3 | Bender Bending Rodriguez | Robot        |   7500 | NULL                                                                    |
|          4 | Hubert J. Farnsworth     | CEO          |  20000 | NULL                                                                    |
|          5 | John A. Zoidberg         | Physician    |     25 | NULL                                                                    |
|          6 | Amy Wong                 | Intern       |   5000 | NULL                                                                    |
|          7 | Hermes Conrad            | Bureaucrat   |  10000 | NULL                                                                    |
|          8 | Scruffy Scruffington     | Janitor      |   5000 | NULL                                                                    |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
8 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from planet;
+----------+------------------+------------------+
| PlanetID | Name             | Coordinates      |
+----------+------------------+------------------+
|        1 | Omicron Persei 8 |    89475345.3545 |
|        2 | Decapod X        | 65498463216.3466 |
|        3 | Mars             |   32435021.65468 |
|        4 | Omega III        |    98432121.5464 |
|        5 | Tarantulon VI    | 849842198.354654 |
|        6 | Cannibalon       |  654321987.21654 |
|        7 | DogDoo VII       |  65498721354.688 |
|        8 | Nintenduu 64     |  6543219894.1654 |
|        9 | Amazonia         | 65432135979.6547 |
+----------+------------------+------------------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from has_clearance;
+----------+--------+-------+
| Employee | Planet | Level |
+----------+--------+-------+
|        1 |      1 |     2 |
|        1 |      2 |     3 |
|        2 |      3 |     2 |
|        2 |      4 |     4 |
|        3 |      5 |     2 |
|        3 |      6 |     4 |
|        4 |      7 |     1 |
+----------+--------+-------+
7 rows in set (0.00 sec)

MariaDB [csd2204s18]> select employee.name,has_clearance.planet,has_clearance.level from has_clearance left join employee on has_clearance.amployee = employee.employee_id;
ERROR 1054 (42S22): Unknown column 'has_clearance.amployee' in 'on clause'
MariaDB [csd2204s18]> select employee.name,has_clearance.planet,has_clearance.level from has_clearance left join employee on has_clearance.employee = employee.employee_id;
ERROR 1054 (42S22): Unknown column 'employee.employee_id' in 'on clause'
MariaDB [csd2204s18]> select employee.name,has_clearance.planet,has_clearance.level from has_clearance left join employee on has_clearance.employee = employee.employeeid;
+--------------------------+--------+-------+
| name                     | planet | level |
+--------------------------+--------+-------+
| Phillip J. Fry           |      1 |     2 |
| Phillip J. Fry           |      2 |     3 |
| Turanga Leela            |      3 |     2 |
| Turanga Leela            |      4 |     4 |
| Bender Bending Rodriguez |      5 |     2 |
| Bender Bending Rodriguez |      6 |     4 |
| Hubert J. Farnsworth     |      7 |     1 |
+--------------------------+--------+-------+
7 rows in set (0.00 sec)

MariaDB [csd2204s18]> select employee.name,has_clearance.employee,has_clearance.planet,has_clearance.level from has_clearance left join employee on has_clearance.employee = employee.employeeid;
+--------------------------+----------+--------+-------+
| name                     | employee | planet | level |
+--------------------------+----------+--------+-------+
| Phillip J. Fry           |        1 |      1 |     2 |
| Phillip J. Fry           |        1 |      2 |     3 |
| Turanga Leela            |        2 |      3 |     2 |
| Turanga Leela            |        2 |      4 |     4 |
| Bender Bending Rodriguez |        3 |      5 |     2 |
| Bender Bending Rodriguez |        3 |      6 |     4 |
| Hubert J. Farnsworth     |        4 |      7 |     1 |
+--------------------------+----------+--------+-------+
7 rows in set (0.00 sec)

MariaDB [csd2204s18]> select employee.name,has_clearance.employee,has_clearance.planet,has_clearance.level from has_clearance left join employee on has_clearance.employee = employee.employeeid group by employee;
+--------------------------+----------+--------+-------+
| name                     | employee | planet | level |
+--------------------------+----------+--------+-------+
| Phillip J. Fry           |        1 |      1 |     2 |
| Turanga Leela            |        2 |      3 |     2 |
| Bender Bending Rodriguez |        3 |      5 |     2 |
| Hubert J. Farnsworth     |        4 |      7 |     1 |
+--------------------------+----------+--------+-------+
4 rows in set (0.00 sec)

MariaDB [csd2204s18]> select employee.name,has_clearance.planet from has_clearance left join employee on has_clearance.employee = employee.employeeid group by employee;
+--------------------------+--------+
| name                     | planet |
+--------------------------+--------+
| Phillip J. Fry           |      1 |
| Turanga Leela            |      3 |
| Bender Bending Rodriguez |      5 |
| Hubert J. Farnsworth     |      7 |
+--------------------------+--------+
4 rows in set (0.00 sec)

MariaDB [csd2204s18]> select employee.name,has_clearance.planet from has_clearance left join employee on has_clearance.employee = employee.employeeid group by planet;
+--------------------------+--------+
| name                     | planet |
+--------------------------+--------+
| Phillip J. Fry           |      1 |
| Phillip J. Fry           |      2 |
| Turanga Leela            |      3 |
| Turanga Leela            |      4 |
| Bender Bending Rodriguez |      5 |
| Bender Bending Rodriguez |      6 |
| Hubert J. Farnsworth     |      7 |
+--------------------------+--------+
7 rows in set (0.00 sec)

MariaDB [csd2204s18]> select employee.name,has_clearance.planet from has_clearance left join employee on has_clearance.employee = employee.employeeid;
+--------------------------+--------+
| name                     | planet |
+--------------------------+--------+
| Phillip J. Fry           |      1 |
| Phillip J. Fry           |      2 |
| Turanga Leela            |      3 |
| Turanga Leela            |      4 |
| Bender Bending Rodriguez |      5 |
| Bender Bending Rodriguez |      6 |
| Hubert J. Farnsworth     |      7 |
+--------------------------+--------+
7 rows in set (0.00 sec)

MariaDB [csd2204s18]> select employee.name,has_clearance.planet from has_clearance inner join employee on has_clearance.employee = employee.employeeid;
+--------------------------+--------+
| name                     | planet |
+--------------------------+--------+
| Phillip J. Fry           |      1 |
| Phillip J. Fry           |      2 |
| Turanga Leela            |      3 |
| Turanga Leela            |      4 |
| Bender Bending Rodriguez |      5 |
| Bender Bending Rodriguez |      6 |
| Hubert J. Farnsworth     |      7 |
+--------------------------+--------+
7 rows in set (0.00 sec)

MariaDB [csd2204s18]> select employee.name,has_clearance.planet from has_clearance right join employee on has_clearance.employee = employee.employeeid;
+--------------------------+--------+
| name                     | planet |
+--------------------------+--------+
| Phillip J. Fry           |      1 |
| Phillip J. Fry           |      2 |
| Turanga Leela            |      3 |
| Turanga Leela            |      4 |
| Bender Bending Rodriguez |      5 |
| Bender Bending Rodriguez |      6 |
| Hubert J. Farnsworth     |      7 |
| John A. Zoidberg         |   NULL |
| Amy Wong                 |   NULL |
| Hermes Conrad            |   NULL |
| Scruffy Scruffington     |   NULL |
+--------------------------+--------+
11 rows in set (0.00 sec)

MariaDB [csd2204s18]> create or replace view v4 as select employee.name,has_clearance.planet from has_clearance inner join employee on has_clearance.employee = employee.employeeid;
Query OK, 0 rows affected (0.05 sec)

MariaDB [csd2204s18]> select * from v4;
+--------------------------+--------+
| name                     | planet |
+--------------------------+--------+
| Phillip J. Fry           |      1 |
| Phillip J. Fry           |      2 |
| Turanga Leela            |      3 |
| Turanga Leela            |      4 |
| Bender Bending Rodriguez |      5 |
| Bender Bending Rodriguez |      6 |
| Hubert J. Farnsworth     |      7 |
+--------------------------+--------+
7 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from shipment;
+------------+--------------+---------+--------+
| ShipmentID | ShipmentDate | Manager | Planet |
+------------+--------------+---------+--------+
|          1 | 3004-05-11   |       1 |      1 |
|          2 | 3004-05-11   |       1 |      2 |
|          3 | NULL         |       2 |      3 |
|          4 | NULL         |       2 |      4 |
|          5 | NULL         |       7 |      5 |
+------------+--------------+---------+--------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from package;
+----------+---------------+-------------------+--------+--------+-----------+
| Shipment | PackageNumber | Contents          | Weight | Sender | Recipient |
+----------+---------------+-------------------+--------+--------+-----------+
|        1 |             1 | Undeclared        |    1.5 |      1 |         2 |
|        2 |             1 | Undeclared        |     10 |      2 |         3 |
|        2 |             2 | A bucket of krill |      2 |      8 |         7 |
|        3 |             1 | Undeclared        |     15 |      3 |         4 |
|        3 |             2 | Undeclared        |      3 |      5 |         1 |
|        3 |             3 | Undeclared        |      7 |      2 |         3 |
|        4 |             1 | Undeclared        |      5 |      4 |         5 |
|        4 |             2 | Undeclared        |     27 |      1 |         2 |
|        5 |             1 | Undeclared        |    100 |      5 |         1 |
+----------+---------------+-------------------+--------+--------+-----------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from client;
+---------------+-------------------+
| AccountNumber | Name              |
+---------------+-------------------+
|             1 | Zapp Brannigan    |
|             2 | Al Gore's Head    |
|             3 | Barbados Slim     |
|             4 | Ogden Wernstrom   |
|             5 | Leo Wong          |
|             6 | Lrrr              |
|             7 | John Zoidberg     |
|             8 | John Zoidfarb     |
|             9 | Morbo             |
|            10 | Judge John Whitey |
|            11 | Calculon          |
+---------------+-------------------+
11 rows in set (0.00 sec)

MariaDB [csd2204s18]> select shipment.shipmentdate,package.sender,package.recipient,client.name,package.weight from shipment inner join package on shipment.shipment_id = package.shipment inner join client on shipment.shipment = client.accountnumber; 
ERROR 1054 (42S22): Unknown column 'shipment.shipment_id' in 'on clause'
MariaDB [csd2204s18]> select shipment.shipmentdate,package.sender,package.recipient,client.name,package.weight from shipment inner join package on shipment.shipmentid = package.shipment inner join client on shipment.shipment = client.accountnumber; 
ERROR 1054 (42S22): Unknown column 'shipment.shipment' in 'on clause'
MariaDB [csd2204s18]> select shipment.shipmentdate,package.sender,package.recipient,client.name,package.weight from shipment inner join package on shipment.shipmentid = package.shipment inner join client on shipment.shipmentid = client.accountnumber; 
+--------------+--------+-----------+-----------------+--------+
| shipmentdate | sender | recipient | name            | weight |
+--------------+--------+-----------+-----------------+--------+
| 3004-05-11   |      1 |         2 | Zapp Brannigan  |    1.5 |
| 3004-05-11   |      2 |         3 | Al Gore's Head  |     10 |
| 3004-05-11   |      8 |         7 | Al Gore's Head  |      2 |
| NULL         |      3 |         4 | Barbados Slim   |     15 |
| NULL         |      5 |         1 | Barbados Slim   |      3 |
| NULL         |      2 |         3 | Barbados Slim   |      7 |
| NULL         |      4 |         5 | Ogden Wernstrom |      5 |
| NULL         |      1 |         2 | Ogden Wernstrom |     27 |
| NULL         |      5 |         1 | Leo Wong        |    100 |
+--------------+--------+-----------+-----------------+--------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select shipment.shipmentdate,package.sender,package.recipient,client.name,package.weight from shipment inner join package on shipment.shipmentid = package.shipment inner join client on shipment.shipmentid = client.accountnumber having weight>5 && weight<10; 
+--------------+--------+-----------+---------------+--------+
| shipmentdate | sender | recipient | name          | weight |
+--------------+--------+-----------+---------------+--------+
| NULL         |      2 |         3 | Barbados Slim |      7 |
+--------------+--------+-----------+---------------+--------+
1 row in set (0.00 sec)

MariaDB [csd2204s18]> 
MariaDB [csd2204s18]> select shipment.shipmentdate,package.sender,package.recipient,client.name,package.weight from shipment inner join package on shipment.shipmentid = package.shipment inner join client on shipment.shipmentid = client.accountnumber having weight in (5,6,7,8,9.10); 
+--------------+--------+-----------+-----------------+--------+
| shipmentdate | sender | recipient | name            | weight |
+--------------+--------+-----------+-----------------+--------+
| NULL         |      2 |         3 | Barbados Slim   |      7 |
| NULL         |      4 |         5 | Ogden Wernstrom |      5 |
+--------------+--------+-----------+-----------------+--------+
2 rows in set (0.00 sec)

MariaDB [csd2204s18]> select shipment.shipmentdate,package.sender,package.recipient,client.name,package.weight from shipment inner join package on shipment.shipmentid = package.shipment inner join client on shipment.shipmentid = client.accountnumber having weight in (5,6,7,8,9,10); 
+--------------+--------+-----------+-----------------+--------+
| shipmentdate | sender | recipient | name            | weight |
+--------------+--------+-----------+-----------------+--------+
| 3004-05-11   |      2 |         3 | Al Gore's Head  |     10 |
| NULL         |      2 |         3 | Barbados Slim   |      7 |
| NULL         |      4 |         5 | Ogden Wernstrom |      5 |
+--------------+--------+-----------+-----------------+--------+
3 rows in set (0.00 sec)

MariaDB [csd2204s18]> create or replace view v5 as select shipment.shipmentdate,package.sender,package.recipient,client.name,package.weight from shipment inner join package on shipment.shipmentid = package.shipment inner join client on shipment.shipmentid = client.accountnumber having weight in (5,6,7,8,9,10);
Query OK, 0 rows affected (0.08 sec)

MariaDB [csd2204s18]> select * from view v5;
ERROR 1146 (42S02): Table 'csd2204s18.view' doesn't exist
MariaDB [csd2204s18]> select * from v5;
+--------------+--------+-----------+-----------------+--------+
| shipmentdate | sender | recipient | name            | weight |
+--------------+--------+-----------+-----------------+--------+
| 3004-05-11   |      2 |         3 | Al Gore's Head  |     10 |
| NULL         |      2 |         3 | Barbados Slim   |      7 |
| NULL         |      4 |         5 | Ogden Wernstrom |      5 |
+--------------+--------+-----------+-----------------+--------+
3 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from shipment;
+------------+--------------+---------+--------+
| ShipmentID | ShipmentDate | Manager | Planet |
+------------+--------------+---------+--------+
|          1 | 3004-05-11   |       1 |      1 |
|          2 | 3004-05-11   |       1 |      2 |
|          3 | NULL         |       2 |      3 |
|          4 | NULL         |       2 |      4 |
|          5 | NULL         |       7 |      5 |
+------------+--------------+---------+--------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from planet;
+----------+------------------+------------------+
| PlanetID | Name             | Coordinates      |
+----------+------------------+------------------+
|        1 | Omicron Persei 8 |    89475345.3545 |
|        2 | Decapod X        | 65498463216.3466 |
|        3 | Mars             |   32435021.65468 |
|        4 | Omega III        |    98432121.5464 |
|        5 | Tarantulon VI    | 849842198.354654 |
|        6 | Cannibalon       |  654321987.21654 |
|        7 | DogDoo VII       |  65498721354.688 |
|        8 | Nintenduu 64     |  6543219894.1654 |
|        9 | Amazonia         | 65432135979.6547 |
+----------+------------------+------------------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select planet.planetid,shipment.shipment_id,shipment.shipmentdate,shipment.manager,shipment.planet from shipment inner join planet on planet.planetid = shipment.planet;
ERROR 1054 (42S22): Unknown column 'shipment.shipment_id' in 'field list'
MariaDB [csd2204s18]> select planet.planetid,shipment.shipmentid,shipment.shipmentdate,shipment.manager,shipment.planet from shipment inner join planet on planet.planetid = shipment.planet;
+----------+------------+--------------+---------+--------+
| planetid | shipmentid | shipmentdate | manager | planet |
+----------+------------+--------------+---------+--------+
|        1 |          1 | 3004-05-11   |       1 |      1 |
|        2 |          2 | 3004-05-11   |       1 |      2 |
|        3 |          3 | NULL         |       2 |      3 |
|        4 |          4 | NULL         |       2 |      4 |
|        5 |          5 | NULL         |       7 |      5 |
+----------+------------+--------------+---------+--------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> select planet.planetid,shipment.shipmentid,shipment.shipmentdate,shipment.manager,shipment.planet from shipment inner join planet on planet.planetid = shipment.planet where name = 'mars' || 'decapod';
+----------+------------+--------------+---------+--------+
| planetid | shipmentid | shipmentdate | manager | planet |
+----------+------------+--------------+---------+--------+
|        3 |          3 | NULL         |       2 |      3 |
+----------+------------+--------------+---------+--------+
1 row in set, 4 warnings (0.00 sec)

MariaDB [csd2204s18]> create or replace view v6 as  select planet.planetid,shipment.shipmentid,shipment.shipmentdate,shipment.manager,shipment.planet from shipment inner join planet on planet.planetid = shipment.planet where name = 'mars' || 'decapod';
Query OK, 0 rows affected, 1 warning (0.05 sec)

MariaDB [csd2204s18]> select * from v6;
+----------+------------+--------------+---------+--------+
| planetid | shipmentid | shipmentdate | manager | planet |
+----------+------------+--------------+---------+--------+
|        3 |          3 | NULL         |       2 |      3 |
+----------+------------+--------------+---------+--------+
1 row in set, 6 warnings (0.00 sec)

MariaDB [csd2204s18]> select * from client;
+---------------+-------------------+
| AccountNumber | Name              |
+---------------+-------------------+
|             1 | Zapp Brannigan    |
|             2 | Al Gore's Head    |
|             3 | Barbados Slim     |
|             4 | Ogden Wernstrom   |
|             5 | Leo Wong          |
|             6 | Lrrr              |
|             7 | John Zoidberg     |
|             8 | John Zoidfarb     |
|             9 | Morbo             |
|            10 | Judge John Whitey |
|            11 | Calculon          |
+---------------+-------------------+
11 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from has_clearance;
+----------+--------+-------+
| Employee | Planet | Level |
+----------+--------+-------+
|        1 |      1 |     2 |
|        1 |      2 |     3 |
|        2 |      3 |     2 |
|        2 |      4 |     4 |
|        3 |      5 |     2 |
|        3 |      6 |     4 |
|        4 |      7 |     1 |
+----------+--------+-------+
7 rows in set (0.00 sec)

MariaDB [csd2204s18]> select name from client where packageid not in(select packageid from has_clerance);
ERROR 1146 (42S02): Table 'csd2204s18.has_clerance' doesn't exist
MariaDB [csd2204s18]> select name from client where packageid not in(select packageid from has_clearance);
ERROR 1054 (42S22): Unknown column 'packageid' in 'IN/ALL/ANY subquery'
MariaDB [csd2204s18]> select * from package;
+----------+---------------+-------------------+--------+--------+-----------+
| Shipment | PackageNumber | Contents          | Weight | Sender | Recipient |
+----------+---------------+-------------------+--------+--------+-----------+
|        1 |             1 | Undeclared        |    1.5 |      1 |         2 |
|        2 |             1 | Undeclared        |     10 |      2 |         3 |
|        2 |             2 | A bucket of krill |      2 |      8 |         7 |
|        3 |             1 | Undeclared        |     15 |      3 |         4 |
|        3 |             2 | Undeclared        |      3 |      5 |         1 |
|        3 |             3 | Undeclared        |      7 |      2 |         3 |
|        4 |             1 | Undeclared        |      5 |      4 |         5 |
|        4 |             2 | Undeclared        |     27 |      1 |         2 |
|        5 |             1 | Undeclared        |    100 |      5 |         1 |
+----------+---------------+-------------------+--------+--------+-----------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from has_clearance;
+----------+--------+-------+
| Employee | Planet | Level |
+----------+--------+-------+
|        1 |      1 |     2 |
|        1 |      2 |     3 |
|        2 |      3 |     2 |
|        2 |      4 |     4 |
|        3 |      5 |     2 |
|        3 |      6 |     4 |
|        4 |      7 |     1 |
+----------+--------+-------+
7 rows in set (0.00 sec)

MariaDB [csd2204s18]> select name from client where employee not in(select employee from has_clearance);
ERROR 1054 (42S22): Unknown column 'employee' in 'IN/ALL/ANY subquery'
MariaDB [csd2204s18]> select name from employee where employee not in(select employee from has_clearance);
ERROR 1054 (42S22): Unknown column 'employee' in 'IN/ALL/ANY subquery'
MariaDB [csd2204s18]> select * from employee;
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
| EmployeeID | Name                     | Position     | Salary | Remarks                                                                 |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
|          1 | Phillip J. Fry           | Delivery boy |   7500 | Not to be confused with the Philip J. Fry from Hovering Squid World 97a |
|          2 | Turanga Leela            | Captain      |  10000 | NULL                                                                    |
|          3 | Bender Bending Rodriguez | Robot        |   7500 | NULL                                                                    |
|          4 | Hubert J. Farnsworth     | CEO          |  20000 | NULL                                                                    |
|          5 | John A. Zoidberg         | Physician    |     25 | NULL                                                                    |
|          6 | Amy Wong                 | Intern       |   5000 | NULL                                                                    |
|          7 | Hermes Conrad            | Bureaucrat   |  10000 | NULL                                                                    |
|          8 | Scruffy Scruffington     | Janitor      |   5000 | NULL                                                                    |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
8 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from client;
+---------------+-------------------+
| AccountNumber | Name              |
+---------------+-------------------+
|             1 | Zapp Brannigan    |
|             2 | Al Gore's Head    |
|             3 | Barbados Slim     |
|             4 | Ogden Wernstrom   |
|             5 | Leo Wong          |
|             6 | Lrrr              |
|             7 | John Zoidberg     |
|             8 | John Zoidfarb     |
|             9 | Morbo             |
|            10 | Judge John Whitey |
|            11 | Calculon          |
+---------------+-------------------+
11 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from packages;
ERROR 1146 (42S02): Table 'csd2204s18.packages' doesn't exist
MariaDB [csd2204s18]> select * from package;
+----------+---------------+-------------------+--------+--------+-----------+
| Shipment | PackageNumber | Contents          | Weight | Sender | Recipient |
+----------+---------------+-------------------+--------+--------+-----------+
|        1 |             1 | Undeclared        |    1.5 |      1 |         2 |
|        2 |             1 | Undeclared        |     10 |      2 |         3 |
|        2 |             2 | A bucket of krill |      2 |      8 |         7 |
|        3 |             1 | Undeclared        |     15 |      3 |         4 |
|        3 |             2 | Undeclared        |      3 |      5 |         1 |
|        3 |             3 | Undeclared        |      7 |      2 |         3 |
|        4 |             1 | Undeclared        |      5 |      4 |         5 |
|        4 |             2 | Undeclared        |     27 |      1 |         2 |
|        5 |             1 | Undeclared        |    100 |      5 |         1 |
+----------+---------------+-------------------+--------+--------+-----------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select client.name,package.content from clientinner join package on client.accountnumber=package.shipment; 
ERROR 1146 (42S02): Table 'csd2204s18.clientinner' doesn't exist
MariaDB [csd2204s18]> select client.name,package.content from client inner join package on client.accountnumber=package.shipment; 
ERROR 1054 (42S22): Unknown column 'package.content' in 'field list'
MariaDB [csd2204s18]> select client.name,package.contents from client inner join package on client.accountnumber=package.shipment; 
+-----------------+-------------------+
| name            | contents          |
+-----------------+-------------------+
| Zapp Brannigan  | Undeclared        |
| Al Gore's Head  | Undeclared        |
| Al Gore's Head  | A bucket of krill |
| Barbados Slim   | Undeclared        |
| Barbados Slim   | Undeclared        |
| Barbados Slim   | Undeclared        |
| Ogden Wernstrom | Undeclared        |
| Ogden Wernstrom | Undeclared        |
| Leo Wong        | Undeclared        |
+-----------------+-------------------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select client.name,package.contents from client inner join package on client.accountnumber=package.shipment where content = 'uncleared'; 
ERROR 1054 (42S22): Unknown column 'content' in 'where clause'
MariaDB [csd2204s18]> select client.name,package.contents from client inner join package on client.accountnumber=package.shipment where contents = 'uncleared'; 
Empty set (0.00 sec)

MariaDB [csd2204s18]> select client.name,package.contents from client inner join package on client.accountnumber=package.shipment where contents like 'uncleared'; 
Empty set (0.00 sec)

MariaDB [csd2204s18]> select client.name,package.contents from client inner join package on client.accountnumber=package.shipment where contents = "uncleared"; 
Empty set (0.00 sec)

MariaDB [csd2204s18]> select client.name,package.contents from client inner join package on client.accountnumber=package.shipment where contents = "uncleared" group by name; 
Empty set (0.00 sec)

MariaDB [csd2204s18]> select client.name,package.contents from client inner join package on client.accountnumber=package.shipment group by name; 
+-----------------+------------+
| name            | contents   |
+-----------------+------------+
| Al Gore's Head  | Undeclared |
| Barbados Slim   | Undeclared |
| Leo Wong        | Undeclared |
| Ogden Wernstrom | Undeclared |
| Zapp Brannigan  | Undeclared |
+-----------------+------------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> create or replace view v7 as select client.name,package.contents from client inner join package on client.accountnumber=package.shipment group by name;
Query OK, 0 rows affected (0.06 sec)

MariaDB [csd2204s18]> select * from v7;
+-----------------+------------+
| name            | contents   |
+-----------------+------------+
| Al Gore's Head  | Undeclared |
| Barbados Slim   | Undeclared |
| Leo Wong        | Undeclared |
| Ogden Wernstrom | Undeclared |
| Zapp Brannigan  | Undeclared |
+-----------------+------------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from package;
+----------+---------------+-------------------+--------+--------+-----------+
| Shipment | PackageNumber | Contents          | Weight | Sender | Recipient |
+----------+---------------+-------------------+--------+--------+-----------+
|        1 |             1 | Undeclared        |    1.5 |      1 |         2 |
|        2 |             1 | Undeclared        |     10 |      2 |         3 |
|        2 |             2 | A bucket of krill |      2 |      8 |         7 |
|        3 |             1 | Undeclared        |     15 |      3 |         4 |
|        3 |             2 | Undeclared        |      3 |      5 |         1 |
|        3 |             3 | Undeclared        |      7 |      2 |         3 |
|        4 |             1 | Undeclared        |      5 |      4 |         5 |
|        4 |             2 | Undeclared        |     27 |      1 |         2 |
|        5 |             1 | Undeclared        |    100 |      5 |         1 |
+----------+---------------+-------------------+--------+--------+-----------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from employee;
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
| EmployeeID | Name                     | Position     | Salary | Remarks                                                                 |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
|          1 | Phillip J. Fry           | Delivery boy |   7500 | Not to be confused with the Philip J. Fry from Hovering Squid World 97a |
|          2 | Turanga Leela            | Captain      |  10000 | NULL                                                                    |
|          3 | Bender Bending Rodriguez | Robot        |   7500 | NULL                                                                    |
|          4 | Hubert J. Farnsworth     | CEO          |  20000 | NULL                                                                    |
|          5 | John A. Zoidberg         | Physician    |     25 | NULL                                                                    |
|          6 | Amy Wong                 | Intern       |   5000 | NULL                                                                    |
|          7 | Hermes Conrad            | Bureaucrat   |  10000 | NULL                                                                    |
|          8 | Scruffy Scruffington     | Janitor      |   5000 | NULL                                                                    |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
8 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from client;
+---------------+-------------------+
| AccountNumber | Name              |
+---------------+-------------------+
|             1 | Zapp Brannigan    |
|             2 | Al Gore's Head    |
|             3 | Barbados Slim     |
|             4 | Ogden Wernstrom   |
|             5 | Leo Wong          |
|             6 | Lrrr              |
|             7 | John Zoidberg     |
|             8 | John Zoidfarb     |
|             9 | Morbo             |
|            10 | Judge John Whitey |
|            11 | Calculon          |
+---------------+-------------------+
11 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from planet;
+----------+------------------+------------------+
| PlanetID | Name             | Coordinates      |
+----------+------------------+------------------+
|        1 | Omicron Persei 8 |    89475345.3545 |
|        2 | Decapod X        | 65498463216.3466 |
|        3 | Mars             |   32435021.65468 |
|        4 | Omega III        |    98432121.5464 |
|        5 | Tarantulon VI    | 849842198.354654 |
|        6 | Cannibalon       |  654321987.21654 |
|        7 | DogDoo VII       |  65498721354.688 |
|        8 | Nintenduu 64     |  6543219894.1654 |
|        9 | Amazonia         | 65432135979.6547 |
+----------+------------------+------------------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select  * from client;
+---------------+-------------------+
| AccountNumber | Name              |
+---------------+-------------------+
|             1 | Zapp Brannigan    |
|             2 | Al Gore's Head    |
|             3 | Barbados Slim     |
|             4 | Ogden Wernstrom   |
|             5 | Leo Wong          |
|             6 | Lrrr              |
|             7 | John Zoidberg     |
|             8 | John Zoidfarb     |
|             9 | Morbo             |
|            10 | Judge John Whitey |
|            11 | Calculon          |
+---------------+-------------------+
11 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from employee;
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
| EmployeeID | Name                     | Position     | Salary | Remarks                                                                 |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
|          1 | Phillip J. Fry           | Delivery boy |   7500 | Not to be confused with the Philip J. Fry from Hovering Squid World 97a |
|          2 | Turanga Leela            | Captain      |  10000 | NULL                                                                    |
|          3 | Bender Bending Rodriguez | Robot        |   7500 | NULL                                                                    |
|          4 | Hubert J. Farnsworth     | CEO          |  20000 | NULL                                                                    |
|          5 | John A. Zoidberg         | Physician    |     25 | NULL                                                                    |
|          6 | Amy Wong                 | Intern       |   5000 | NULL                                                                    |
|          7 | Hermes Conrad            | Bureaucrat   |  10000 | NULL                                                                    |
|          8 | Scruffy Scruffington     | Janitor      |   5000 | NULL                                                                    |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
8 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from employee;
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
| EmployeeID | Name                     | Position     | Salary | Remarks                                                                 |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
|          1 | Phillip J. Fry           | Delivery boy |   7500 | Not to be confused with the Philip J. Fry from Hovering Squid World 97a |
|          2 | Turanga Leela            | Captain      |  10000 | NULL                                                                    |
|          3 | Bender Bending Rodriguez | Robot        |   7500 | NULL                                                                    |
|          4 | Hubert J. Farnsworth     | CEO          |  20000 | NULL                                                                    |
|          5 | John A. Zoidberg         | Physician    |     25 | NULL                                                                    |
|          6 | Amy Wong                 | Intern       |   5000 | NULL                                                                    |
|          7 | Hermes Conrad            | Bureaucrat   |  10000 | NULL                                                                    |
|          8 | Scruffy Scruffington     | Janitor      |   5000 | NULL                                                                    |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
8 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from package;
+----------+---------------+-------------------+--------+--------+-----------+
| Shipment | PackageNumber | Contents          | Weight | Sender | Recipient |
+----------+---------------+-------------------+--------+--------+-----------+
|        1 |             1 | Undeclared        |    1.5 |      1 |         2 |
|        2 |             1 | Undeclared        |     10 |      2 |         3 |
|        2 |             2 | A bucket of krill |      2 |      8 |         7 |
|        3 |             1 | Undeclared        |     15 |      3 |         4 |
|        3 |             2 | Undeclared        |      3 |      5 |         1 |
|        3 |             3 | Undeclared        |      7 |      2 |         3 |
|        4 |             1 | Undeclared        |      5 |      4 |         5 |
|        4 |             2 | Undeclared        |     27 |      1 |         2 |
|        5 |             1 | Undeclared        |    100 |      5 |         1 |
+----------+---------------+-------------------+--------+--------+-----------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select package.recipient,package.contents,client.name,employee.name from package inner join client on package.shipment = client.accountnumber inner join employee on client.accountnumber=employee.employeeid;
+-----------+-------------------+-----------------+--------------------------+
| recipient | contents          | name            | name                     |
+-----------+-------------------+-----------------+--------------------------+
|         2 | Undeclared        | Zapp Brannigan  | Phillip J. Fry           |
|         3 | Undeclared        | Al Gore's Head  | Turanga Leela            |
|         7 | A bucket of krill | Al Gore's Head  | Turanga Leela            |
|         4 | Undeclared        | Barbados Slim   | Bender Bending Rodriguez |
|         1 | Undeclared        | Barbados Slim   | Bender Bending Rodriguez |
|         3 | Undeclared        | Barbados Slim   | Bender Bending Rodriguez |
|         5 | Undeclared        | Ogden Wernstrom | Hubert J. Farnsworth     |
|         2 | Undeclared        | Ogden Wernstrom | Hubert J. Farnsworth     |
|         1 | Undeclared        | Leo Wong        | John A. Zoidberg         |
+-----------+-------------------+-----------------+--------------------------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select package.recipient,package.contents,client.name,employee.name from client inner join employee on client.accountnumber = employee.employeeid inner join package on employee.emploeeid=package.shipment;
ERROR 1054 (42S22): Unknown column 'employee.emploeeid' in 'on clause'
MariaDB [csd2204s18]> select package.recipient,package.contents,client.name,employee.name from client inner join employee on client.accountnumber = employee.employeeid inner join package on employee.employeeid=package.shipment;
+-----------+-------------------+-----------------+--------------------------+
| recipient | contents          | name            | name                     |
+-----------+-------------------+-----------------+--------------------------+
|         2 | Undeclared        | Zapp Brannigan  | Phillip J. Fry           |
|         3 | Undeclared        | Al Gore's Head  | Turanga Leela            |
|         7 | A bucket of krill | Al Gore's Head  | Turanga Leela            |
|         4 | Undeclared        | Barbados Slim   | Bender Bending Rodriguez |
|         1 | Undeclared        | Barbados Slim   | Bender Bending Rodriguez |
|         3 | Undeclared        | Barbados Slim   | Bender Bending Rodriguez |
|         5 | Undeclared        | Ogden Wernstrom | Hubert J. Farnsworth     |
|         2 | Undeclared        | Ogden Wernstrom | Hubert J. Farnsworth     |
|         1 | Undeclared        | Leo Wong        | John A. Zoidberg         |
+-----------+-------------------+-----------------+--------------------------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from employee;
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
| EmployeeID | Name                     | Position     | Salary | Remarks                                                                 |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
|          1 | Phillip J. Fry           | Delivery boy |   7500 | Not to be confused with the Philip J. Fry from Hovering Squid World 97a |
|          2 | Turanga Leela            | Captain      |  10000 | NULL                                                                    |
|          3 | Bender Bending Rodriguez | Robot        |   7500 | NULL                                                                    |
|          4 | Hubert J. Farnsworth     | CEO          |  20000 | NULL                                                                    |
|          5 | John A. Zoidberg         | Physician    |     25 | NULL                                                                    |
|          6 | Amy Wong                 | Intern       |   5000 | NULL                                                                    |
|          7 | Hermes Conrad            | Bureaucrat   |  10000 | NULL                                                                    |
|          8 | Scruffy Scruffington     | Janitor      |   5000 | NULL                                                                    |
+------------+--------------------------+--------------+--------+-------------------------------------------------------------------------+
8 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from shipment;
+------------+--------------+---------+--------+
| ShipmentID | ShipmentDate | Manager | Planet |
+------------+--------------+---------+--------+
|          1 | 3004-05-11   |       1 |      1 |
|          2 | 3004-05-11   |       1 |      2 |
|          3 | NULL         |       2 |      3 |
|          4 | NULL         |       2 |      4 |
|          5 | NULL         |       7 |      5 |
+------------+--------------+---------+--------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from planet;
+----------+------------------+------------------+
| PlanetID | Name             | Coordinates      |
+----------+------------------+------------------+
|        1 | Omicron Persei 8 |    89475345.3545 |
|        2 | Decapod X        | 65498463216.3466 |
|        3 | Mars             |   32435021.65468 |
|        4 | Omega III        |    98432121.5464 |
|        5 | Tarantulon VI    | 849842198.354654 |
|        6 | Cannibalon       |  654321987.21654 |
|        7 | DogDoo VII       |  65498721354.688 |
|        8 | Nintenduu 64     |  6543219894.1654 |
|        9 | Amazonia         | 65432135979.6547 |
+----------+------------------+------------------+
9 rows in set (0.00 sec)

MariaDB [csd2204s18]> select employee.name,shipment.shipmentid,panet.planetid from planet inner join shipment on planet.planetid = shipment.shipmentid inner join employee on shipment.shipment_id = employee.employeeid;
ERROR 1054 (42S22): Unknown column 'panet.planetid' in 'field list'
MariaDB [csd2204s18]> select employee.name,shipment.shipmentid,planet.planetid from planet inner join shipment on planet.planetid = shipment.shipmentid inner join employee on shipment.shipment_id = employee.employeeid;
ERROR 1054 (42S22): Unknown column 'shipment.shipment_id' in 'on clause'
MariaDB [csd2204s18]> select employee.name,shipment.shipmentid,planet.planetid from planet inner join shipment on planet.planetid = shipment.shipmentid inner join employee on shipment.shipmentid = employee.employeeid;
+--------------------------+------------+----------+
| name                     | shipmentid | planetid |
+--------------------------+------------+----------+
| Phillip J. Fry           |          1 |        1 |
| Turanga Leela            |          2 |        2 |
| Bender Bending Rodriguez |          3 |        3 |
| Hubert J. Farnsworth     |          4 |        4 |
| John A. Zoidberg         |          5 |        5 |
+--------------------------+------------+----------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> select employee.name,shipment.shipmentid,planet.planetid,planet.planet.name from planet inner join shipment on planet.planetid = shipment.shipmentid inner join employee on shipment.shipmentid = employee.employeeid;
ERROR 1054 (42S22): Unknown column 'planet.planet.name' in 'field list'
MariaDB [csd2204s18]> select employee.name,shipment.shipmentid,planet.planetid,planet.name from planet inner join shipment on planet.planetid = shipment.shipmentid inner join employee on shipment.shipmentid = employee.employeeid;
+--------------------------+------------+----------+------------------+
| name                     | shipmentid | planetid | name             |
+--------------------------+------------+----------+------------------+
| Phillip J. Fry           |          1 |        1 | Omicron Persei 8 |
| Turanga Leela            |          2 |        2 | Decapod X        |
| Bender Bending Rodriguez |          3 |        3 | Mars             |
| Hubert J. Farnsworth     |          4 |        4 | Omega III        |
| John A. Zoidberg         |          5 |        5 | Tarantulon VI    |
+--------------------------+------------+----------+------------------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> select employee.name,shipment.shipmentid,planet.planetid,planet.name from planet inner join shipment on planet.planetid = shipment.shipmentid inner join employee on shipment.shipmentid = employee.employeeid where name like "omega%";
ERROR 1052 (23000): Column 'name' in where clause is ambiguous
MariaDB [csd2204s18]> select employee.name,shipment.shipmentid,planet.planetid,planet.name from planet inner join shipment on planet.planetid = shipment.shipmentid inner join employee on shipment.shipmentid = employee.employeeid where name like 'omega%';
ERROR 1052 (23000): Column 'name' in where clause is ambiguous
MariaDB [csd2204s18]> select employee.name,shipment.shipmentid,planet.planetid,planet.name from planet inner join shipment on planet.planetid = shipment.shipmentid inner join employee on shipment.shipmentid = employee.employeeid where name like 'omega%' where planet_id = 4;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'where planet_id = 4' at line 1
MariaDB [csd2204s18]> select employee.name,shipment.shipmentid,planet.planetid,planet.name from planet inner join shipment on planet.planetid = shipment.shipmentid inner join employee on shipment.shipmentid = employee.employeeid where name like 'omega%' where planet_id = '4';
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'where planet_id = '4'' at line 1
MariaDB [csd2204s18]> select employee.name,shipment.shipmentid,planet.planetid,planet.name from planet inner join shipment on planet.planetid = shipment.shipmentid inner join employee on shipment.shipmentid = employee.employeeid where planet_id = '4';
ERROR 1054 (42S22): Unknown column 'planet_id' in 'where clause'
MariaDB [csd2204s18]> select employee.name,shipment.shipmentid,planet.planetid,planet.name from planet inner join shipment on planet.planetid = shipment.shipmentid inner join employee on shipment.shipmentid = employee.employeeid where planetid = '4';
+----------------------+------------+----------+-----------+
| name                 | shipmentid | planetid | name      |
+----------------------+------------+----------+-----------+
| Hubert J. Farnsworth |          4 |        4 | Omega III |
+----------------------+------------+----------+-----------+
1 row in set (0.00 sec)

MariaDB [csd2204s18]> create or replace view v9 as select employee.name,shipment.shipmentid,planet.planetid,planet.name from planet inner join shipment on planet.planetid = shipment.shipmentid inner join employee on shipment.shipmentid = employee.employeeid where planetid = '4';
ERROR 1060 (42S21): Duplicate column name 'name'
MariaDB [csd2204s18]> select employee.name,shipment.shipmentid,planet.planetid from planet inner join shipment on planet.planetid = shipment.shipmentid inner join employee on shipment.shipmentid = employee.employeeid where planetid = '4';
+----------------------+------------+----------+
| name                 | shipmentid | planetid |
+----------------------+------------+----------+
| Hubert J. Farnsworth |          4 |        4 |
+----------------------+------------+----------+
1 row in set (0.00 sec)

MariaDB [csd2204s18]> create or replace view v9 as  select employee.name,shipment.shipmentid,planet.planetid from planet inner join shipment on planet.planetid = shipment.shipmentid inner join employee on shipment.shipmentid = employee.employeeid where planetid = '4';
Query OK, 0 rows affected (0.06 sec)

MariaDB [csd2204s18]> select * from v9;
+----------------------+------------+----------+
| name                 | shipmentid | planetid |
+----------------------+------------+----------+
| Hubert J. Farnsworth |          4 |        4 |
+----------------------+------------+----------+
1 row in set (0.00 sec)

MariaDB [csd2204s18]> select * from shipment;
+------------+--------------+---------+--------+
| ShipmentID | ShipmentDate | Manager | Planet |
+------------+--------------+---------+--------+
|          1 | 3004-05-11   |       1 |      1 |
|          2 | 3004-05-11   |       1 |      2 |
|          3 | NULL         |       2 |      3 |
|          4 | NULL         |       2 |      4 |
|          5 | NULL         |       7 |      5 |
+------------+--------------+---------+--------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> update shipment add shipmentdate = 2018 -05-24 where shipmentid = 3;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'add shipmentdate = 2018 -05-24 where shipmentid = 3' at line 1
MariaDB [csd2204s18]> update shipment add shipmentdate = '2018 -05-24' where shipmentid = '3';
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'add shipmentdate = '2018 -05-24' where shipmentid = '3'' at line 1
MariaDB [csd2204s18]> update shipment set shipmentdate = '2018 -05-24' where shipmentid = '3';
Query OK, 1 row affected, 1 warning (0.08 sec)
Rows matched: 1  Changed: 1  Warnings: 1

MariaDB [csd2204s18]> update shipment set shipmentdate = '2018 -05-24' where shipmentid = '4';
Query OK, 1 row affected, 1 warning (0.08 sec)
Rows matched: 1  Changed: 1  Warnings: 1

MariaDB [csd2204s18]> update shipment set shipmentdate = '2018 -05-24' where shipmentid = '5';
Query OK, 1 row affected, 1 warning (0.09 sec)
Rows matched: 1  Changed: 1  Warnings: 1

MariaDB [csd2204s18]> select * from shipment;
+------------+--------------+---------+--------+
| ShipmentID | ShipmentDate | Manager | Planet |
+------------+--------------+---------+--------+
|          1 | 3004-05-11   |       1 |      1 |
|          2 | 3004-05-11   |       1 |      2 |
|          3 | 0000-00-00   |       2 |      3 |
|          4 | 0000-00-00   |       2 |      4 |
|          5 | 0000-00-00   |       7 |      5 |
+------------+--------------+---------+--------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> exit;

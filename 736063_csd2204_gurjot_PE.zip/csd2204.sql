-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2018 at 05:26 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `csd2204s18`
--

-- --------------------------------------------------------

--
-- Table structure for table `ac_mast`
--

CREATE TABLE `ac_mast` (
  `ac_type` varchar(3) NOT NULL,
  `ac_no` int(4) NOT NULL,
  `cust_no` int(5) DEFAULT NULL,
  `bal` float(10,2) DEFAULT NULL,
  `od_limit` float(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ac_mast`
--

INSERT INTO `ac_mast` (`ac_type`, `ac_no`, `cust_no`, `bal`, `od_limit`) VALUES
('Nom', 7384, 4, 670993.00, 63.95),
('Nom', 7385, 5, 288059.56, 60.88),
('Nom', 7388, 8, 25746.27, 4.02),
('Nom', 7389, 9, 601610.81, 60.40),
('Nom', 7392, 12, 755910.56, 1.19),
('Nom', 7398, 18, 163516.94, 64.78),
('Nom', 7399, 19, 775272.94, 89.86),
('Nom', 7402, 22, 809629.19, 40.26),
('Nom', 7404, 24, 410049.12, 7.64),
('Nom', 7407, 27, 67230.20, 34.84),
('Nom', 7413, 33, 602023.50, 57.56),
('Nom', 7414, 34, 104566.00, 31.98),
('Nom', 7417, 37, 880123.06, 50.45),
('Nom', 7420, 40, 421817.50, 58.67),
('Nom', 7421, 41, 417777.31, 48.15),
('Nom', 7425, 45, 39227.99, 31.03),
('Nom', 7428, 48, 767979.94, 13.97),
('Nom', 7430, 50, 605986.75, 15.62),
('Per', 7380, 1, 73095.65, 68.76),
('Per', 7381, 2, 124568.10, 72.93),
('Per', 7386, 6, 93326.37, 57.15),
('Per', 7387, 7, 168593.98, 1.32),
('Per', 7391, 11, 763414.38, 38.30),
('Per', 7393, 13, 483423.75, 88.42),
('Per', 7394, 14, 139009.64, 27.57),
('Per', 7395, 15, 412877.75, 67.30),
('Per', 7396, 16, 680869.56, 76.70),
('Per', 7400, 20, 132790.86, 20.28),
('Per', 7408, 28, 166271.86, 71.72),
('Per', 7409, 29, 803530.75, 5.18),
('Per', 7410, 30, 404689.34, 92.26),
('Per', 7411, 31, 762468.62, 92.69),
('Per', 7412, 32, 659072.25, 58.22),
('Per', 7415, 35, 886057.44, 75.63),
('Per', 7418, 38, 199855.61, 70.27),
('Per', 7419, 39, 479726.75, 84.82),
('Per', 7426, 46, 307005.81, 95.79),
('Per', 7429, 49, 573211.75, 71.30),
('Rea', 7382, 3, 164869.95, 75.26),
('Rea', 7390, 10, 673308.44, 68.05),
('Rea', 7397, 17, 487271.62, 87.98),
('Rea', 7401, 21, 10407.95, 74.40),
('Rea', 7403, 23, 255007.12, 96.47),
('Rea', 7405, 25, 551044.12, 2.36),
('Rea', 7406, 26, 488585.91, 43.20),
('Rea', 7416, 36, 115012.35, 53.43),
('Rea', 7422, 42, 177030.11, 51.61),
('Rea', 7423, 43, 944915.00, 98.60),
('Rea', 7424, 44, 747101.88, 95.28),
('Rea', 7427, 47, 503831.16, 56.29);

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `bill_id` int(11) NOT NULL,
  `cust_id` int(11) DEFAULT NULL,
  `cart_id` int(11) DEFAULT NULL,
  `shipping_cost` varchar(20) DEFAULT NULL,
  `sub_cost` varchar(20) DEFAULT NULL,
  `total_cost` varchar(20) DEFAULT NULL,
  `tax` varchar(20) DEFAULT NULL,
  `payment_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`bill_id`, `cust_id`, `cart_id`, `shipping_cost`, `sub_cost`, `total_cost`, `tax`, `payment_id`) VALUES
(301, 1, 101, '24.86.4.36', '178.106.126.245', '56.208.26.221', '190.60.44.131', 201),
(302, 2, 102, '64.113.61.251', '77.46.47.215', '249.158.162.82', '48.241.164.246', 202),
(303, 3, 103, '5.160.247.56', '218.58.75.66', '174.13.153.226', '79.148.119.0', 203),
(304, 4, 104, '137.19.26.205', '71.142.118.106', '70.22.20.99', '122.103.111.107', 204),
(305, 5, 105, '50.187.14.137', '219.182.221.12', '74.117.77.116', '148.123.124.237', 205),
(306, 6, 106, '207.252.97.6', '68.81.170.239', '130.70.209.179', '9.140.163.232', 206),
(307, 7, 107, '145.202.254.222', '136.178.212.14', '114.24.98.190', '130.58.224.155', 207),
(308, 8, 108, '30.42.213.110', '233.201.182.203', '68.88.40.3', '61.189.213.234', 208),
(309, 9, 109, '21.21.194.232', '58.62.141.50', '55.196.247.18', '140.2.189.29', 209),
(310, 10, 110, '25.147.41.3', '114.198.118.200', '211.218.176.65', '175.58.168.56', 210),
(311, 11, 111, '135.135.218.32', '177.105.35.148', '215.102.244.230', '196.106.114.68', 211),
(312, 12, 112, '214.30.41.45', '246.212.13.156', '144.239.18.154', '127.133.10.126', 212),
(313, 13, 113, '52.174.114.46', '244.219.217.160', '41.233.41.200', '157.62.66.131', 213),
(314, 14, 114, '204.227.140.235', '11.70.230.94', '53.238.241.51', '190.226.240.187', 214),
(315, 15, 115, '136.245.65.225', '194.83.20.165', '132.174.250.203', '46.186.177.175', 215),
(316, 16, 116, '242.245.10.70', '110.152.44.12', '142.168.11.91', '26.131.202.127', 216),
(317, 17, 117, '95.66.160.168', '1.117.133.211', '34.242.235.119', '37.197.180.248', 217),
(318, 18, 118, '252.7.2.24', '86.40.248.171', '131.172.63.33', '165.46.103.119', 218),
(319, 19, 119, '145.214.36.99', '200.200.55.201', '15.14.55.250', '114.132.40.66', 219),
(320, 20, 120, '137.31.41.251', '104.196.77.174', '167.188.48.154', '68.67.126.84', 220),
(321, 21, 121, '175.130.228.2', '176.70.45.70', '32.103.155.125', '103.24.165.133', 221),
(322, 22, 122, '99.60.251.3', '67.126.97.56', '230.60.148.160', '208.174.38.50', 222),
(323, 23, 123, '198.32.247.217', '220.166.138.188', '158.170.20.162', '92.62.90.52', 223),
(324, 24, 124, '69.234.136.238', '100.77.9.186', '30.44.20.110', '157.59.67.37', 224);

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `brand_id` int(11) NOT NULL,
  `brand_name` varchar(20) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brand_id`, `brand_name`, `category_id`) VALUES
(26, 'canada goose', 89),
(27, 'sunbeam', 92),
(28, 'roots canada', 89),
(29, 'st.amour', 92),
(30, 'nike', 89),
(31, 'guess', 89),
(32, 'gucci', 89),
(33, 'lakme', 90),
(34, 'nivea', 90),
(35, 'M.A.C.', 90),
(36, 'maybelline', 90),
(37, 'L Oreal', 90),
(38, 'gerber', 92),
(39, 'L.A Girl', 90),
(40, 'bobbi brown', 90),
(41, 'revlon', 90),
(42, 'lee', 94),
(43, 'heelys', 94),
(44, 'starbury', 94),
(45, 'subway', 84),
(46, 'mcdonald', 84),
(47, 'elle decoration', 93),
(48, 'coca cola', 87),
(49, 'ajoto', 88),
(50, 'local', 85),
(51, 'barbie', 91),
(52, 'LEGO', 91),
(53, 'brand fuel', 93),
(54, 'adidas', 95),
(55, 'brooks', 95),
(56, 'rexall', 97),
(57, 'brunet', 97),
(58, 'matrox', 96),
(59, 'nortel', 96),
(60, 'american signature', 86),
(61, 'ashley', 86);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `total_cost` decimal(8,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `quantity`, `total_cost`) VALUES
(101, 9, '67403.93'),
(102, 61, '33881.63'),
(103, 46, '62275.89'),
(104, 28, '70682.09'),
(105, 76, '91347.90'),
(106, 45, '23156.41'),
(107, 84, '60952.35'),
(108, 82, '62348.51'),
(109, 42, '60973.02'),
(110, 17, '61198.39'),
(111, 51, '56562.06'),
(112, 37, '24036.08'),
(113, 16, '15130.00'),
(114, 94, '25866.49'),
(115, 87, '78529.61'),
(116, 81, '67715.34'),
(117, 71, '68153.06'),
(118, 14, '42482.01'),
(119, 20, '10864.34'),
(120, 83, '72518.55'),
(121, 5, '46938.63'),
(122, 70, '4255.13'),
(123, 49, '98981.87'),
(124, 45, '86119.15');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(84, 'fast food'),
(85, 'music'),
(86, 'furniture'),
(87, 'beverages'),
(88, 'stationary'),
(89, 'cloth'),
(90, 'cosmetics'),
(91, 'Toy'),
(92, 'grocery'),
(93, 'decoration'),
(94, 'footwear'),
(95, 'sports equipment'),
(96, 'electronic'),
(97, 'pharmacy');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `COUNTRY_ID` varchar(2) NOT NULL,
  `COUNTRY_NAME` varchar(40) DEFAULT NULL,
  `REGION_ID` decimal(10,0) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`COUNTRY_ID`, `COUNTRY_NAME`, `REGION_ID`) VALUES
('AR', 'Argentina', '2'),
('AU', 'Australia', '3'),
('BE', 'Belgium', '1'),
('BR', 'Brazil', '2'),
('CA', 'Canada', '2'),
('CH', 'Switzerland', '1'),
('CN', 'China', '3'),
('DE', 'Germany', '1'),
('DK', 'Denmark', '1'),
('EG', 'Egypt', '4'),
('FR', 'France', '1'),
('HK', 'HongKong', '3'),
('IL', 'Israel', '4'),
('IN', 'India', '3'),
('IT', 'Italy', '1'),
('JP', 'Japan', '3'),
('KW', 'Kuwait', '4'),
('MX', 'Mexico', '2'),
('NG', 'Nigeria', '4'),
('NL', 'Netherlands', '1'),
('SG', 'Singapore', '3'),
('UK', 'United Kingdom', '1'),
('US', 'United States of America', '2'),
('ZM', 'Zambia', '4'),
('ZW', 'Zimbabwe', '4');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cust_id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cust_id`, `first_name`, `last_name`, `email`, `gender`, `username`, `password`, `address`, `country`) VALUES
(1, 'Rori', 'Boothe', 'rboothe0@linkedin.com', 'male', 'rboothe0', 'K64DfM8ax', '56989 Katie Hill', 'india'),
(2, 'Nikolia', 'Besson', 'nbesson1@mail.ru', 'Female', 'nbesson1', 'TroXRecK', '35 Orin Hill', 'india'),
(3, 'Rakel', 'Brosnan', 'rbrosnan2@tmall.com', 'Female', 'rbrosnan2', 'hfFfeo8fbM', '655 Hermina Avenue', 'india'),
(4, 'Lonnard', 'Malek', 'lmalek3@accuweather.com', 'Male', 'lmalek3', 'PhhjVzAsjIQP', '91736 Kennedy Hill', 'india'),
(5, 'Chauncey', 'Tremmil', 'ctremmil4@mediafire.com', 'Male', 'ctremmil4', 'mPWSrtb', '024 Graceland Court', 'india'),
(6, 'Babb', 'Gelly', 'bgelly5@geocities.jp', 'Female', 'bgelly5', 'haesredg', '14 Carey Alley', 'india'),
(7, 'Bevin', 'Chesswas', 'bchesswas6@vk.com', 'Male', 'bchesswas6', 'vGxr8SCoRu', '2 Mesta Center', 'india'),
(8, 'Rogerio', 'Mushrow', 'rmushrow7@goo.ne.jp', 'Male', 'rmushrow7', 'T8mIMqCx4wRd', '2 Autumn Leaf Street', 'india'),
(9, 'Brita', 'Rhucroft', 'brhucroft8@163.com', 'Female', 'brhucroft8', 's2vgi5elm8', '6664 Eagle Crest Avenue', 'india'),
(10, 'Anton', 'Tarbox', 'atarbox9@hp.com', 'Male', 'atarbox9', 'X0IalYmKA', '068 Shasta Court', 'india'),
(11, 'Nonna', 'Brimilcombe', 'nbrimilcombea@newsvine.com', 'Female', 'nbrimilcombea', '7fULhCst', '677 Nova Junction', 'canada'),
(12, 'Shaw', 'Calafate', 'scalafateb@mapquest.com', 'Male', 'scalafateb', '3vPZHW8Y', '6041 Warner Circle', 'canada'),
(13, 'Johnathan', 'Ricardot', 'jricardotc@globo.com', 'Male', 'jricardotc', 'L7osLBw', '505 Sullivan Plaza', 'canada'),
(14, 'Vaughan', 'Truse', 'vtrused@infoseek.co.jp', 'Male', 'vtrused', 'jbJxTsQUzXF', '47 Glendale Court', 'canada'),
(15, 'Renaldo', 'Buston', 'rbustone@slashdot.org', 'Male', 'rbustone', 'IYi7eG', '226 Hanson Drive', 'canada'),
(16, 'Caressa', 'Wharfe', 'cwharfef@yale.edu', 'Female', 'cwharfef', 'qUOFG1OtPSKa', '4245 Walton Center', 'canada'),
(17, 'Tildi', 'Sheard', 'tsheardg@state.tx.us', 'male', 'tsheardg', 'tfEGwTu', '8851 Pankratz Alley', 'canada'),
(18, 'Cheston', 'Wogan', 'cwoganh@edublogs.org', 'Male', 'cwoganh', 'J56bZwCgtB', '329 Del Sol Drive', 'canada'),
(19, 'Alika', 'Nabarro', 'anabarroi@nature.com', 'Female', 'anabarroi', 'FhA5gUC9', '3 Lakewood Point', 'canada'),
(20, 'Iago', 'Smallpiece', 'ismallpiecej@360.cn', 'Male', 'ismallpiecej', '38Owrnas2MPS', '94 David Circle', 'canada'),
(21, 'Fidelio', 'Camillo', 'fcamillok@dedecms.com', 'Male', 'fcamillok', '3qrL4PeB', '2 Sullivan Drive', 'USA'),
(22, 'Athena', 'Patise', 'apatisel@techcrunch.com', 'Female', 'apatisel', '0TAfJw0excn8', '17520 Northland Circle', 'USA'),
(23, 'Raphael', 'Stivey', 'rstiveym@netlog.com', 'Male', 'rstiveym', 'jqKgoekUY', '28 Dapin Drive', 'USA'),
(24, 'Paddy', 'Taber', 'ptabern@flavors.me', 'Male', 'ptabern', 'C6PY2BrwOW2', '99 Buell Drive', 'USA');

-- --------------------------------------------------------

--
-- Table structure for table `cust_mast`
--

CREATE TABLE `cust_mast` (
  `cust_no` int(5) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `addr1` varchar(50) DEFAULT NULL,
  `addr2` varchar(50) DEFAULT NULL,
  `addr3` varchar(50) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cust_mast`
--

INSERT INTO `cust_mast` (`cust_no`, `name`, `addr1`, `addr2`, `addr3`, `city`, `state`) VALUES
(1, 'Allissa Vallentin', '43', '33785 Crest Line Road', '41905', 'Migrate', 'Kentucky'),
(2, 'Blancha Hackleton', '723', '123 Milwaukee Court', '73147', 'Oklahoma City', 'Oklahoma'),
(3, 'Free Crambie', '03', '3 Stephen Circle', '34665', 'Pinellas Park', 'Florida'),
(4, 'Leodora Di Gregorio', '6', '44 Helena Lane', '32225', 'Jacksonville', 'Florida'),
(5, 'Ninnetta Chaucer', '7', '923 Vernon Way', '92878', 'Corona', 'California'),
(6, 'Yulma Massei', '06', '37 6th Hill', '28230', 'Charlotte', 'North Carolina'),
(7, 'Janis Hugin', '8980', '8817 Fisk Trail', '37939', 'Knoxville', 'Tennessee'),
(8, 'Rosalia Cristoforetti', '359', '48 Katie Point', '64504', 'Saint Joseph', 'Missouri'),
(9, 'Daryl Loudyan', '81180', '498 Green Alley', '30033', 'Decatur', 'Georgia'),
(10, 'Mendel Hussell', '177', '0 Huxley Avenue', '33710', 'Saint Petersburg', 'Florida'),
(11, 'Dmitri Littlecote', '5524', '0 Shelley Plaza', '64199', 'Kansas City', 'Missouri'),
(12, 'Babs Drakeford', '36', '1404 Knutson Street', '33075', 'Pompano Beach', 'Florida'),
(13, 'Vasily Galero', '77', '2444 Debra Place', '92030', 'Escondido', 'California'),
(14, 'Ravi Craster', '6', '21 Goodland Plaza', '20910', 'Silver Spring', 'Maryland'),
(15, 'Tessi Biskup', '805', '212 Russell Center', '11254', 'Brooklyn', 'New York'),
(16, 'Astrix Dow', '49495', '14 Florence Junction', '35295', 'Birmingham', 'Alabama'),
(17, 'Lacee Burvill', '53367', '2754 Magdeline Pass', '80915', 'Colorado Springs', 'Colorado'),
(18, 'Eldon Hadgraft', '21', '6 Texas Junction', '48295', 'Detroit', 'Michigan'),
(19, 'Chane La Rosa', '40', '32630 Shelley Parkway', '25721', 'Huntington', 'West Virginia'),
(20, 'Bryan Gilli', '37', '569 Morning Parkway', '12232', 'Albany', 'New York'),
(21, 'Adolpho Preedy', '2870', '463 Brickson Park Court', '77010', 'Houston', 'Texas'),
(22, 'Lorain Mence', '4', '864 Nova Lane', '10170', 'New York City', 'New York'),
(23, 'Kristien Jouandet', '55', '9 Muir Court', '20073', 'Washington', 'District of Columbia'),
(24, 'Frederic Petruk', '4', '44250 Oxford Point', '90060', 'Los Angeles', 'California'),
(25, 'Ross Jeune', '10', '5 Boyd Crossing', '32277', 'Jacksonville', 'Florida'),
(26, 'Yorgos Radmer', '14726', '446 Prairie Rose Way', '85284', 'Tempe', 'Arizona'),
(27, 'Waylen Brimmicombe', '0', '226 Lighthouse Bay Point', '47805', 'Terre Haute', 'Indiana'),
(28, 'Ainsley Maulin', '8444', '0 Crownhardt Street', '23509', 'Norfolk', 'Virginia'),
(29, 'Florie Leek', '92881', '522 Rockefeller Park', '92640', 'Fullerton', 'California'),
(30, 'Jed Norkutt', '2122', '91549 Merchant Alley', '76121', 'Fort Worth', 'Texas'),
(31, 'Burg Ipgrave', '099', '2 Dapin Lane', '72209', 'Little Rock', 'Arkansas'),
(32, 'Sebastien Leeburne', '06', '8 Burrows Place', '80044', 'Aurora', 'Colorado'),
(33, 'Nicolette Bottoner', '3', '32396 Forest Dale Plaza', '10275', 'New York City', 'New York'),
(34, 'Mersey Phelipeau', '45495', '420 Welch Alley', '31136', 'Atlanta', 'Georgia'),
(35, 'Chantalle Geratasch', '34', '4910 Hoffman Road', '94250', 'Sacramento', 'California'),
(36, 'Cari Tooth', '5845', '79326 Towne Trail', '75710', 'Tyler', 'Texas'),
(37, 'Billy Casotti', '62671', '4 Logan Center', '55146', 'Saint Paul', 'Minnesota'),
(38, 'Allister Jiracek', '14', '2 Loomis Parkway', '94164', 'San Francisco', 'California'),
(39, 'Gussi Reading', '40385', '07 Melrose Hill', '38188', 'Memphis', 'Tennessee'),
(40, 'Kiley Kenninghan', '7978', '8962 Huxley Center', '46896', 'Fort Wayne', 'Indiana'),
(41, 'Cory Chalk', '8', '278 Heath Point', '10079', 'New York City', 'New York'),
(42, 'Morton Woolaghan', '5', '3339 Stone Corner Circle', '98417', 'Tacoma', 'Washington'),
(43, 'Shaine Fearns', '6', '46 Village Center', '22096', 'Reston', 'Virginia'),
(44, 'Jereme Fallanche', '38', '2345 Garrison Center', '22333', 'Alexandria', 'Virginia'),
(45, 'Tyler O\'Corrigane', '24172', '4696 Bashford Point', '75799', 'Tyler', 'Texas'),
(46, 'Lauryn Snewin', '2126', '6 Norway Maple Plaza', '38150', 'Memphis', 'Tennessee'),
(47, 'Ruth Fishpoole', '6', '8146 Bartelt Alley', '75074', 'Plano', 'Texas'),
(48, 'Valene Alasdair', '1980', '05091 Maple Road', '85015', 'Phoenix', 'Arizona'),
(49, 'Faustina Hake', '3', '26951 Norway Maple Drive', '80228', 'Denver', 'Colorado'),
(50, 'Meg Tuite', '57', '27 Lien Road', '22234', 'Arlington', 'Virginia');

-- --------------------------------------------------------

--
-- Stand-in structure for view `d6`
-- (See below for the actual view)
--
CREATE TABLE `d6` (
`first_name` varchar(20)
,`last_name` varchar(25)
,`salary` decimal(8,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `d7`
-- (See below for the actual view)
--
CREATE TABLE `d7` (
`first_name` varchar(20)
,`last_name` varchar(25)
,`salary` decimal(8,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `DEPARTMENT_ID` decimal(4,0) NOT NULL DEFAULT '0',
  `DEPARTMENT_NAME` varchar(30) NOT NULL,
  `MANAGER_ID` decimal(6,0) DEFAULT NULL,
  `LOCATION_ID` decimal(4,0) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`DEPARTMENT_ID`, `DEPARTMENT_NAME`, `MANAGER_ID`, `LOCATION_ID`) VALUES
('10', 'Administration', '200', '1700'),
('20', 'Marketing', '201', '1800'),
('30', 'Purchasing', '114', '1700'),
('40', 'Human Resources', '203', '2400'),
('50', 'Shipping', '121', '1500'),
('60', 'IT', '103', '1400'),
('70', 'Public Relations', '204', '2700'),
('80', 'Sales', '145', '2500'),
('90', 'Executive', '100', '1700'),
('100', 'Finance', '108', '1700'),
('110', 'Accounting', '205', '1700'),
('120', 'Treasury', '0', '1700'),
('130', 'Corporate Tax', '0', '1700'),
('140', 'Control And Credit', '0', '1700'),
('150', 'Shareholder Services', '0', '1700'),
('160', 'Benefits', '0', '1700'),
('170', 'Manufacturing', '0', '1700'),
('180', 'Construction', '0', '1700'),
('190', 'Contracting', '0', '1700'),
('200', 'Operations', '0', '1700'),
('210', 'IT Support', '0', '1700'),
('220', 'NOC', '0', '1700'),
('230', 'IT Helpdesk', '0', '1700'),
('240', 'Government Sales', '0', '1700'),
('250', 'Retail Sales', '0', '1700'),
('260', 'Recruiting', '0', '1700'),
('270', 'Payroll', '0', '1700');

-- --------------------------------------------------------

--
-- Table structure for table `dept`
--

CREATE TABLE `dept` (
  `dno` int(3) NOT NULL,
  `name` varchar(15) DEFAULT NULL,
  `location` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dept`
--

INSERT INTO `dept` (`dno`, `name`, `location`) VALUES
(1, 'Research and De', 'Colmeal'),
(2, 'Engineering', 'Chejiazhuang'),
(3, 'Business Develo', 'Rostov'),
(4, 'Human Resources', 'GargaliÃ¡noi'),
(5, 'Services', 'BodzanÃ³w'),
(6, 'Marketing', 'Daitou'),
(7, 'Engineering', 'Sambong'),
(8, 'Engineering', 'CubatÃ£o'),
(9, 'Legal', 'Vukovar'),
(10, 'Legal', 'Laval'),
(11, 'Research and De', 'Å?ubowo'),
(12, 'Support', 'OgÅ?ri-shimogÅ?'),
(13, 'Human Resources', 'Wuyanquan'),
(14, 'Services', 'Mainz'),
(15, 'Support', 'IperÃ³'),
(16, 'Human Resources', 'Jatake'),
(17, 'Sales', 'Berlin'),
(18, 'Marketing', 'Ã%bolowa'),
(19, 'Business Develo', 'Sagua la Grande'),
(20, 'Business Develo', 'Longhua'),
(21, 'Services', 'Anserma'),
(22, 'Product Managem', 'Jindong'),
(23, 'Sales', 'Amahusu'),
(24, 'Sales', 'Nixi'),
(25, 'Sales', 'Sukamaju'),
(26, 'Marketing', 'Bulupayung'),
(27, 'Engineering', 'Maha Sarakham'),
(28, 'Research and De', 'Monte Carmelo'),
(29, 'Marketing', 'Severnyy'),
(30, 'Product Managem', 'Tangjiawan'),
(31, 'Support', 'Yanai'),
(32, 'Human Resources', 'San JosÃ© de Ocoa'),
(33, 'Legal', 'Macau'),
(34, 'Human Resources', 'Giporlos'),
(35, 'Product Managem', 'Kuantan'),
(36, 'Research and De', 'Trondheim'),
(37, 'Research and De', 'NÄ?á¸©iyat as Sabâ?~'),
(38, 'Accounting', 'HeydÉTrabad'),
(39, 'Research and De', 'Pavlohrad'),
(40, 'Product Managem', 'Gudauta'),
(41, 'Accounting', 'Mojkovac'),
(42, 'Engineering', 'Chutove'),
(43, 'Sales', 'Pakemitan Dua'),
(44, 'Marketing', 'Khabarovsk'),
(45, 'Services', 'Santa Marta de Penag'),
(46, 'Human Resources', 'JaquÃ©'),
(47, 'Sales', 'Rudka'),
(49, 'Accounting', 'Smarhonâ?T'),
(50, 'Services', 'ParanaÃ­ba');

-- --------------------------------------------------------

--
-- Table structure for table `emp`
--

CREATE TABLE `emp` (
  `emp_no` int(5) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `jdate` date DEFAULT NULL,
  `dept` int(3) DEFAULT NULL,
  `desig` varchar(20) DEFAULT NULL,
  `basic` float(10,2) DEFAULT NULL,
  `da` float(10,2) DEFAULT NULL,
  `hra` float(10,2) DEFAULT NULL,
  `pf` float(10,2) DEFAULT NULL,
  `it` float(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp`
--

INSERT INTO `emp` (`emp_no`, `name`, `jdate`, `dept`, `desig`, `basic`, `da`, `hra`, `pf`, `it`) VALUES
(51, 'gurjant', NULL, 51, 'master', 234.56, 456.68, 567.79, 345.79, 234.89),
(52, 'gurtej', NULL, 51, 'master', 234.36, 476.68, 547.79, 365.79, 224.89),
(53, 'simmi', '0000-00-00', 54, 'clerk', 45.89, 56.90, 45.89, 45.00, 90.78),
(55, 'gurjant', NULL, 53, 'finance', 130.26, 276.63, 347.70, 464.78, 614.80),
(56, 'simran', NULL, 53, 'finance', 130.27, 266.63, 347.60, 463.78, 613.80);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `EMPLOYEE_ID` decimal(6,0) NOT NULL DEFAULT '0',
  `FIRST_NAME` varchar(20) DEFAULT NULL,
  `LAST_NAME` varchar(25) NOT NULL,
  `EMAIL` varchar(25) NOT NULL,
  `PHONE_NUMBER` varchar(20) DEFAULT NULL,
  `HIRE_DATE` date NOT NULL,
  `JOB_ID` varchar(10) NOT NULL,
  `SALARY` decimal(8,2) DEFAULT NULL,
  `COMMISSION_PCT` decimal(2,2) DEFAULT NULL,
  `MANAGER_ID` decimal(6,0) DEFAULT NULL,
  `DEPARTMENT_ID` decimal(4,0) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`EMPLOYEE_ID`, `FIRST_NAME`, `LAST_NAME`, `EMAIL`, `PHONE_NUMBER`, `HIRE_DATE`, `JOB_ID`, `SALARY`, `COMMISSION_PCT`, `MANAGER_ID`, `DEPARTMENT_ID`) VALUES
('100', 'Steven', 'King', 'SKING', '515.123.4567', '1987-06-17', 'AD_PRES', '24000.00', '0.00', '0', '90'),
('101', 'Neena', 'Kochhar', 'NKOCHHAR', '515.123.4568', '1987-06-18', 'AD_VP', '17000.00', '0.00', '100', '90'),
('102', 'Lex', 'De Haan', 'LDEHAAN', '515.123.4569', '1987-06-19', 'AD_VP', '17000.00', '0.00', '100', '90'),
('103', 'Alexander', 'Hunold', 'AHUNOLD', '590.423.4567', '1987-06-20', 'IT_PROG', '9000.00', '0.00', '102', '60'),
('104', 'Bruce', 'Ernst', 'BERNST', '590.423.4568', '1987-06-21', 'IT_PROG', '6000.00', '0.00', '103', '60'),
('105', 'David', 'Austin', 'DAUSTIN', '590.423.4569', '1987-06-22', 'IT_PROG', '4800.00', '0.00', '103', '60'),
('106', 'Valli', 'Pataballa', 'VPATABAL', '590.423.4560', '1987-06-23', 'IT_PROG', '4800.00', '0.00', '103', '60'),
('107', 'Diana', 'Lorentz', 'DLORENTZ', '590.423.5567', '1987-06-24', 'IT_PROG', '4200.00', '0.00', '103', '60'),
('108', 'Nancy', 'Greenberg', 'NGREENBE', '515.124.4569', '1987-06-25', 'FI_MGR', '12000.00', '0.00', '101', '100'),
('109', 'Daniel', 'Faviet', 'DFAVIET', '515.124.4169', '1987-06-26', 'FI_ACCOUNT', '9000.00', '0.00', '108', '100'),
('110', 'John', 'Chen', 'JCHEN', '515.124.4269', '1987-06-27', 'FI_ACCOUNT', '8200.00', '0.00', '108', '100'),
('111', 'Ismael', 'Sciarra', 'ISCIARRA', '515.124.4369', '1987-06-28', 'FI_ACCOUNT', '7700.00', '0.00', '108', '100'),
('112', 'Jose Manuel', 'Urman', 'JMURMAN', '515.124.4469', '1987-06-29', 'FI_ACCOUNT', '7800.00', '0.00', '108', '100'),
('113', 'Luis', 'Popp', 'LPOPP', '515.124.4567', '1987-06-30', 'FI_ACCOUNT', '6900.00', '0.00', '108', '100'),
('114', 'Den', 'Raphaely', 'DRAPHEAL', '515.127.4561', '1987-07-01', 'PU_MAN', '11000.00', '0.00', '100', '30'),
('115', 'Alexander', 'Khoo', 'AKHOO', '515.127.4562', '1987-07-02', 'PU_CLERK', '3100.00', '0.00', '114', '30'),
('116', 'Shelli', 'Baida', 'SBAIDA', '515.127.4563', '1987-07-03', 'PU_CLERK', '2900.00', '0.00', '114', '30'),
('117', 'Sigal', 'Tobias', 'STOBIAS', '515.127.4564', '1987-07-04', 'PU_CLERK', '2800.00', '0.00', '114', '30'),
('118', 'Guy', 'Himuro', 'GHIMURO', '515.127.4565', '1987-07-05', 'PU_CLERK', '2600.00', '0.00', '114', '30'),
('119', 'Karen', 'Colmenares', 'KCOLMENA', '515.127.4566', '1987-07-06', 'PU_CLERK', '2500.00', '0.00', '114', '30'),
('120', 'Matthew', 'Weiss', 'MWEISS', '650.123.1234', '1987-07-07', 'ST_MAN', '8000.00', '0.00', '100', '50'),
('121', 'Adam', 'Fripp', 'AFRIPP', '650.123.2234', '1987-07-08', 'ST_MAN', '8200.00', '0.00', '100', '50'),
('122', 'Payam', 'Kaufling', 'PKAUFLIN', '650.123.3234', '1987-07-09', 'ST_MAN', '7900.00', '0.00', '100', '50'),
('123', 'Shanta', 'Vollman', 'SVOLLMAN', '650.123.4234', '1987-07-10', 'ST_MAN', '6500.00', '0.00', '100', '50'),
('124', 'Kevin', 'Mourgos', 'KMOURGOS', '650.123.5234', '1987-07-11', 'ST_MAN', '5800.00', '0.00', '100', '50'),
('125', 'Julia', 'Nayer', 'JNAYER', '650.124.1214', '1987-07-12', 'ST_CLERK', '3200.00', '0.00', '120', '50'),
('126', 'Irene', 'Mikkilineni', 'IMIKKILI', '650.124.1224', '1987-07-13', 'ST_CLERK', '2700.00', '0.00', '120', '50'),
('127', 'James', 'Landry', 'JLANDRY', '650.124.1334', '1987-07-14', 'ST_CLERK', '2400.00', '0.00', '120', '50'),
('128', 'Steven', 'Markle', 'SMARKLE', '650.124.1434', '1987-07-15', 'ST_CLERK', '2200.00', '0.00', '120', '50'),
('129', 'Laura', 'Bissot', 'LBISSOT', '650.124.5234', '1987-07-16', 'ST_CLERK', '3300.00', '0.00', '121', '50'),
('130', 'Mozhe', 'Atkinson', 'MATKINSO', '650.124.6234', '1987-07-17', 'ST_CLERK', '2800.00', '0.00', '121', '50'),
('131', 'James', 'Marlow', 'JAMRLOW', '650.124.7234', '1987-07-18', 'ST_CLERK', '2500.00', '0.00', '121', '50'),
('132', 'TJ', 'Olson', 'TJOLSON', '650.124.8234', '1987-07-19', 'ST_CLERK', '2100.00', '0.00', '121', '50'),
('133', 'Jason', 'Mallin', 'JMALLIN', '650.127.1934', '1987-07-20', 'ST_CLERK', '3300.00', '0.00', '122', '50'),
('134', 'Michael', 'Rogers', 'MROGERS', '650.127.1834', '1987-07-21', 'ST_CLERK', '2900.00', '0.00', '122', '50'),
('135', 'Ki', 'Gee', 'KGEE', '650.127.1734', '1987-07-22', 'ST_CLERK', '2400.00', '0.00', '122', '50'),
('136', 'Hazel', 'Philtanker', 'HPHILTAN', '650.127.1634', '1987-07-23', 'ST_CLERK', '2200.00', '0.00', '122', '50'),
('137', 'Renske', 'Ladwig', 'RLADWIG', '650.121.1234', '1987-07-24', 'ST_CLERK', '3600.00', '0.00', '123', '50'),
('138', 'Stephen', 'Stiles', 'SSTILES', '650.121.2034', '1987-07-25', 'ST_CLERK', '3200.00', '0.00', '123', '50'),
('139', 'John', 'Seo', 'JSEO', '650.121.2019', '1987-07-26', 'ST_CLERK', '2700.00', '0.00', '123', '50'),
('140', 'Joshua', 'Patel', 'JPATEL', '650.121.1834', '1987-07-27', 'ST_CLERK', '2500.00', '0.00', '123', '50'),
('141', 'Trenna', 'Rajs', 'TRAJS', '650.121.8009', '1987-07-28', 'ST_CLERK', '3500.00', '0.00', '124', '50'),
('142', 'Curtis', 'Davies', 'CDAVIES', '650.121.2994', '1987-07-29', 'ST_CLERK', '3100.00', '0.00', '124', '50'),
('143', 'Randall', 'Matos', 'RMATOS', '650.121.2874', '1987-07-30', 'ST_CLERK', '2600.00', '0.00', '124', '50'),
('144', 'Peter', 'Vargas', 'PVARGAS', '650.121.2004', '1987-07-31', 'ST_CLERK', '2500.00', '0.00', '124', '50'),
('145', 'John', 'Russell', 'JRUSSEL', '011.44.1344.429268', '1987-08-01', 'SA_MAN', '14000.00', '0.40', '100', '80'),
('146', 'Karen', 'Partners', 'KPARTNER', '011.44.1344.467268', '1987-08-02', 'SA_MAN', '13500.00', '0.30', '100', '80'),
('147', 'Alberto', 'Errazuriz', 'AERRAZUR', '011.44.1344.429278', '1987-08-03', 'SA_MAN', '12000.00', '0.30', '100', '80'),
('148', 'Gerald', 'Cambrault', 'GCAMBRAU', '011.44.1344.619268', '1987-08-04', 'SA_MAN', '11000.00', '0.30', '100', '80'),
('149', 'Eleni', 'Zlotkey', 'EZLOTKEY', '011.44.1344.429018', '1987-08-05', 'SA_MAN', '10500.00', '0.20', '100', '80'),
('150', 'Peter', 'Tucker', 'PTUCKER', '011.44.1344.129268', '1987-08-06', 'SA_REP', '10000.00', '0.30', '145', '80'),
('151', 'David', 'Bernstein', 'DBERNSTE', '011.44.1344.345268', '1987-08-07', 'SA_REP', '9500.00', '0.25', '145', '80'),
('152', 'Peter', 'Hall', 'PHALL', '011.44.1344.478968', '1987-08-08', 'SA_REP', '9000.00', '0.25', '145', '80'),
('153', 'Christopher', 'Olsen', 'COLSEN', '011.44.1344.498718', '1987-08-09', 'SA_REP', '8000.00', '0.20', '145', '80'),
('154', 'Nanette', 'Cambrault', 'NCAMBRAU', '011.44.1344.987668', '1987-08-10', 'SA_REP', '7500.00', '0.20', '145', '80'),
('155', 'Oliver', 'Tuvault', 'OTUVAULT', '011.44.1344.486508', '1987-08-11', 'SA_REP', '7000.00', '0.15', '145', '80'),
('156', 'Janette', 'King', 'JKING', '011.44.1345.429268', '1987-08-12', 'SA_REP', '10000.00', '0.35', '146', '80'),
('157', 'Patrick', 'Sully', 'PSULLY', '011.44.1345.929268', '1987-08-13', 'SA_REP', '9500.00', '0.35', '146', '80'),
('158', 'Allan', 'McEwen', 'AMCEWEN', '011.44.1345.829268', '1987-08-14', 'SA_REP', '9000.00', '0.35', '146', '80'),
('159', 'Lindsey', 'Smith', 'LSMITH', '011.44.1345.729268', '1987-08-15', 'SA_REP', '8000.00', '0.30', '146', '80'),
('160', 'Louise', 'Doran', 'LDORAN', '011.44.1345.629268', '1987-08-16', 'SA_REP', '7500.00', '0.30', '146', '80'),
('161', 'Sarath', 'Sewall', 'SSEWALL', '011.44.1345.529268', '1987-08-17', 'SA_REP', '7000.00', '0.25', '146', '80'),
('162', 'Clara', 'Vishney', 'CVISHNEY', '011.44.1346.129268', '1987-08-18', 'SA_REP', '10500.00', '0.25', '147', '80'),
('163', 'Danielle', 'Greene', 'DGREENE', '011.44.1346.229268', '1987-08-19', 'SA_REP', '9500.00', '0.15', '147', '80'),
('164', 'Mattea', 'Marvins', 'MMARVINS', '011.44.1346.329268', '1987-08-20', 'SA_REP', '7200.00', '0.10', '147', '80'),
('165', 'David', 'Lee', 'DLEE', '011.44.1346.529268', '1987-08-21', 'SA_REP', '6800.00', '0.10', '147', '80'),
('166', 'Sundar', 'Ande', 'SANDE', '011.44.1346.629268', '1987-08-22', 'SA_REP', '6400.00', '0.10', '147', '80'),
('167', 'Amit', 'Banda', 'ABANDA', '011.44.1346.729268', '1987-08-23', 'SA_REP', '6200.00', '0.10', '147', '80'),
('168', 'Lisa', 'Ozer', 'LOZER', '011.44.1343.929268', '1987-08-24', 'SA_REP', '11500.00', '0.25', '148', '80'),
('169', 'Harrison', 'Bloom', 'HBLOOM', '011.44.1343.829268', '1987-08-25', 'SA_REP', '10000.00', '0.20', '148', '80'),
('170', 'Tayler', 'Fox', 'TFOX', '011.44.1343.729268', '1987-08-26', 'SA_REP', '9600.00', '0.20', '148', '80'),
('171', 'William', 'Smith', 'WSMITH', '011.44.1343.629268', '1987-08-27', 'SA_REP', '7400.00', '0.15', '148', '80'),
('172', 'Elizabeth', 'Bates', 'EBATES', '011.44.1343.529268', '1987-08-28', 'SA_REP', '7300.00', '0.15', '148', '80'),
('173', 'Sundita', 'Kumar', 'SKUMAR', '011.44.1343.329268', '1987-08-29', 'SA_REP', '6100.00', '0.10', '148', '80'),
('174', 'Ellen', 'Abel', 'EABEL', '011.44.1644.429267', '1987-08-30', 'SA_REP', '11000.00', '0.30', '149', '80'),
('175', 'Alyssa', 'Hutton', 'AHUTTON', '011.44.1644.429266', '1987-08-31', 'SA_REP', '8800.00', '0.25', '149', '80'),
('176', 'Jonathon', 'Taylor', 'JTAYLOR', '011.44.1644.429265', '1987-09-01', 'SA_REP', '8600.00', '0.20', '149', '80'),
('177', 'Jack', 'Livingston', 'JLIVINGS', '011.44.1644.429264', '1987-09-02', 'SA_REP', '8400.00', '0.20', '149', '80'),
('178', 'Kimberely', 'Grant', 'KGRANT', '011.44.1644.429263', '1987-09-03', 'SA_REP', '7000.00', '0.15', '149', '0'),
('179', 'Charles', 'Johnson', 'CJOHNSON', '011.44.1644.429262', '1987-09-04', 'SA_REP', '6200.00', '0.10', '149', '80'),
('180', 'Winston', 'Taylor', 'WTAYLOR', '650.507.9876', '1987-09-05', 'SH_CLERK', '3200.00', '0.00', '120', '50'),
('181', 'Jean', 'Fleaur', 'JFLEAUR', '650.507.9877', '1987-09-06', 'SH_CLERK', '3100.00', '0.00', '120', '50'),
('182', 'Martha', 'Sullivan', 'MSULLIVA', '650.507.9878', '1987-09-07', 'SH_CLERK', '2500.00', '0.00', '120', '50'),
('183', 'Girard', 'Geoni', 'GGEONI', '650.507.9879', '1987-09-08', 'SH_CLERK', '2800.00', '0.00', '120', '50'),
('184', 'Nandita', 'Sarchand', 'NSARCHAN', '650.509.1876', '1987-09-09', 'SH_CLERK', '4200.00', '0.00', '121', '50'),
('185', 'Alexis', 'Bull', 'ABULL', '650.509.2876', '1987-09-10', 'SH_CLERK', '4100.00', '0.00', '121', '50'),
('186', 'Julia', 'Dellinger', 'JDELLING', '650.509.3876', '1987-09-11', 'SH_CLERK', '3400.00', '0.00', '121', '50'),
('187', 'Anthony', 'Cabrio', 'ACABRIO', '650.509.4876', '1987-09-12', 'SH_CLERK', '3000.00', '0.00', '121', '50'),
('188', 'Kelly', 'Chung', 'KCHUNG', '650.505.1876', '1987-09-13', 'SH_CLERK', '3800.00', '0.00', '122', '50'),
('189', 'Jennifer', 'Dilly', 'JDILLY', '650.505.2876', '1987-09-14', 'SH_CLERK', '3600.00', '0.00', '122', '50'),
('190', 'Timothy', 'Gates', 'TGATES', '650.505.3876', '1987-09-15', 'SH_CLERK', '2900.00', '0.00', '122', '50'),
('191', 'Randall', 'Perkins', 'RPERKINS', '650.505.4876', '1987-09-16', 'SH_CLERK', '2500.00', '0.00', '122', '50'),
('192', 'Sarah', 'Bell', 'SBELL', '650.501.1876', '1987-09-17', 'SH_CLERK', '4000.00', '0.00', '123', '50'),
('193', 'Britney', 'Everett', 'BEVERETT', '650.501.2876', '1987-09-18', 'SH_CLERK', '3900.00', '0.00', '123', '50'),
('194', 'Samuel', 'McCain', 'SMCCAIN', '650.501.3876', '1987-09-19', 'SH_CLERK', '3200.00', '0.00', '123', '50'),
('195', 'Vance', 'Jones', 'VJONES', '650.501.4876', '1987-09-20', 'SH_CLERK', '2800.00', '0.00', '123', '50'),
('196', 'Alana', 'Walsh', 'AWALSH', '650.507.9811', '1987-09-21', 'SH_CLERK', '3100.00', '0.00', '124', '50'),
('197', 'Kevin', 'Feeney', 'KFEENEY', '650.507.9822', '1987-09-22', 'SH_CLERK', '3000.00', '0.00', '124', '50'),
('198', 'Donald', 'OConnell', 'DOCONNEL', '650.507.9833', '1987-09-23', 'SH_CLERK', '2600.00', '0.00', '124', '50'),
('199', 'Douglas', 'Grant', 'DGRANT', '650.507.9844', '1987-09-24', 'SH_CLERK', '2600.00', '0.00', '124', '50'),
('200', 'Jennifer', 'Whalen', 'JWHALEN', '515.123.4444', '1987-09-25', 'AD_ASST', '4400.00', '0.00', '101', '10'),
('201', 'Michael', 'Hartstein', 'MHARTSTE', '515.123.5555', '1987-09-26', 'MK_MAN', '13000.00', '0.00', '100', '20'),
('202', 'Pat', 'Fay', 'PFAY', '603.123.6666', '1987-09-27', 'MK_REP', '6000.00', '0.00', '201', '20'),
('203', 'Susan', 'Mavris', 'SMAVRIS', '515.123.7777', '1987-09-28', 'HR_REP', '6500.00', '0.00', '101', '40'),
('204', 'Hermann', 'Baer', 'HBAER', '515.123.8888', '1987-09-29', 'PR_REP', '10000.00', '0.00', '101', '70'),
('205', 'Shelley', 'Higgins', 'SHIGGINS', '515.123.8080', '1987-09-30', 'AC_MGR', '12000.00', '0.00', '101', '110'),
('206', 'William', 'Gietz', 'WGIETZ', '515.123.8181', '1987-10-01', 'AC_ACCOUNT', '8300.00', '0.00', '205', '110');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `JOB_ID` varchar(10) NOT NULL DEFAULT '',
  `JOB_TITLE` varchar(35) NOT NULL,
  `MIN_SALARY` decimal(6,0) DEFAULT NULL,
  `MAX_SALARY` decimal(6,0) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`JOB_ID`, `JOB_TITLE`, `MIN_SALARY`, `MAX_SALARY`) VALUES
('AD_PRES', 'President', '20000', '40000'),
('AD_VP', 'Administration Vice President', '15000', '30000'),
('AD_ASST', 'Administration Assistant', '3000', '6000'),
('FI_MGR', 'Finance Manager', '8200', '16000'),
('FI_ACCOUNT', 'Accountant', '4200', '9000'),
('AC_MGR', 'Accounting Manager', '8200', '16000'),
('AC_ACCOUNT', 'Public Accountant', '4200', '9000'),
('SA_MAN', 'Sales Manager', '10000', '20000'),
('SA_REP', 'Sales Representative', '6000', '12000'),
('PU_MAN', 'Purchasing Manager', '8000', '15000'),
('PU_CLERK', 'Purchasing Clerk', '2500', '5500'),
('ST_MAN', 'Stock Manager', '5500', '8500'),
('ST_CLERK', 'Stock Clerk', '2000', '5000'),
('SH_CLERK', 'Shipping Clerk', '2500', '5500'),
('IT_PROG', 'Programmer', '4000', '10000'),
('MK_MAN', 'Marketing Manager', '9000', '15000'),
('MK_REP', 'Marketing Representative', '4000', '9000'),
('HR_REP', 'Human Resources Representative', '4000', '9000'),
('PR_REP', 'Public Relations Representative', '4500', '10500');

-- --------------------------------------------------------

--
-- Table structure for table `job_history`
--

CREATE TABLE `job_history` (
  `EMPLOYEE_ID` decimal(6,0) NOT NULL,
  `START_DATE` date NOT NULL,
  `END_DATE` date NOT NULL,
  `JOB_ID` varchar(10) NOT NULL,
  `DEPARTMENT_ID` decimal(4,0) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job_history`
--

INSERT INTO `job_history` (`EMPLOYEE_ID`, `START_DATE`, `END_DATE`, `JOB_ID`, `DEPARTMENT_ID`) VALUES
('102', '1993-01-13', '1998-07-24', 'IT_PROG', '60'),
('101', '1989-09-21', '1993-10-27', 'AC_ACCOUNT', '110'),
('101', '1993-10-28', '1997-03-15', 'AC_MGR', '110'),
('201', '1996-02-17', '1999-12-19', 'MK_REP', '20'),
('114', '1998-03-24', '1999-12-31', 'ST_CLERK', '50'),
('122', '1999-01-01', '1999-12-31', 'ST_CLERK', '50'),
('200', '1987-09-17', '1993-06-17', 'AD_ASST', '90'),
('176', '1998-03-24', '1998-12-31', 'SA_REP', '80'),
('176', '1999-01-01', '1999-12-31', 'SA_MAN', '80'),
('200', '1994-07-01', '1998-12-31', 'AC_ACCOUNT', '90'),
('0', '0000-00-00', '0000-00-00', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `LOCATION_ID` decimal(4,0) NOT NULL DEFAULT '0',
  `STREET_ADDRESS` varchar(40) DEFAULT NULL,
  `POSTAL_CODE` varchar(12) DEFAULT NULL,
  `CITY` varchar(30) NOT NULL,
  `STATE_PROVINCE` varchar(25) DEFAULT NULL,
  `COUNTRY_ID` varchar(2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`LOCATION_ID`, `STREET_ADDRESS`, `POSTAL_CODE`, `CITY`, `STATE_PROVINCE`, `COUNTRY_ID`) VALUES
('1000', '1297 Via Cola di Rie', '989', 'Roma', '', 'IT'),
('1100', '93091 Calle della Testa', '10934', 'Venice', '', 'IT'),
('1200', '2017 Shinjuku-ku', '1689', 'Tokyo', 'Tokyo Prefecture', 'JP'),
('1300', '9450 Kamiya-cho', '6823', 'Hiroshima', '', 'JP'),
('1400', '2014 Jabberwocky Rd', '26192', 'Southlake', 'Texas', 'US'),
('1500', '2011 Interiors Blvd', '99236', 'South San Francisco', 'California', 'US'),
('1600', '2007 Zagora St', '50090', 'South Brunswick', 'New Jersey', 'US'),
('1700', '2004 Charade Rd', '98199', 'Seattle', 'Washington', 'US'),
('1800', '147 Spadina Ave', 'M5V 2L7', 'Toronto', 'Ontario', 'CA'),
('1900', '6092 Boxwood St', 'YSW 9T2', 'Whitehorse', 'Yukon', 'CA'),
('2000', '40-5-12 Laogianggen', '190518', 'Beijing', '', 'CN'),
('2100', '1298 Vileparle (E)', '490231', 'Bombay', 'Maharashtra', 'IN'),
('2200', '12-98 Victoria Street', '2901', 'Sydney', 'New South Wales', 'AU'),
('2300', '198 Clementi North', '540198', 'Singapore', '', 'SG'),
('2400', '8204 Arthur St', '', 'London', '', 'UK'),
('2500', '\"Magdalen Centre', ' The Oxford ', 'OX9 9ZB', 'Oxford', 'Ox'),
('2600', '9702 Chester Road', '9629850293', 'Stretford', 'Manchester', 'UK'),
('2700', 'Schwanthalerstr. 7031', '80925', 'Munich', 'Bavaria', 'DE'),
('2800', 'Rua Frei Caneca 1360', '01307-002', 'Sao Paulo', 'Sao Paulo', 'BR'),
('2900', '20 Rue des Corps-Saints', '1730', 'Geneva', 'Geneve', 'CH'),
('3000', 'Murtenstrasse 921', '3095', 'Bern', 'BE', 'CH'),
('3100', 'Pieter Breughelstraat 837', '3029SK', 'Utrecht', 'Utrecht', 'NL'),
('3200', 'Mariano Escobedo 9991', '11932', 'Mexico City', '\"Distrito Federal', '\"');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `payment_type` varchar(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `payment_type`, `amount`) VALUES
(201, 'debit card', 6522),
(202, 'debit card', 80591),
(203, 'debit card', 55017),
(204, 'debit card', 5873),
(205, 'debit card', 51957),
(206, 'credit card', 96489),
(207, 'debit card', 6951),
(208, 'cash', 83425),
(209, 'cash', 75440),
(210, 'credit card', 75234),
(211, 'cash', 90023),
(212, 'debit card', 78294),
(213, 'credit card', 52979),
(214, 'cash', 13515),
(215, 'credit card', 69498),
(216, 'debit card', 21980),
(217, 'cash', 70457),
(218, 'credit card', 43412),
(219, 'cash', 81027),
(220, 'cash', 38783),
(221, 'debit card', 67249),
(222, 'debit card', 94251),
(223, 'cash', 85292),
(224, 'debit card', 32425);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_model` int(11) DEFAULT NULL,
  `product_name` varchar(50) DEFAULT NULL,
  `product_price` decimal(7,2) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_model`, `product_name`, `product_price`, `brand_id`) VALUES
(131, 5, 'eyeliner', '6847.85', 33),
(132, 16, 'Anisette - Mcguiness', '6057.69', 27),
(133, 23, 'Beer - Original Organic Lager', '6061.62', 48),
(134, 21, 'Pot', '7723.61', 47),
(135, 10, 'show-piece', '8319.80', 53),
(136, 15, 'scenery', '5837.65', 47),
(137, 17, 'pizza', '2114.01', 45),
(138, 15, 'T-shirt', '2026.61', 26),
(139, 25, 'Trouser', '2143.22', 26),
(140, 10, 'painkiller', '7874.01', 56),
(141, 5, 'Mushrooms - Black, Dried', '9963.09', 29),
(142, 17, 'dressing table', '4359.63', 60),
(143, 19, 'capry', '5654.05', 31),
(144, 7, 'refrigerator', '5079.18', 58),
(145, 18, 'football', '7305.91', 55),
(146, 10, 'pencil', '5685.47', 49),
(147, 9, 'formal shoe', '6436.19', 42),
(148, 25, 'car', '1024.93', 52),
(149, 10, 'Onions - Red Pearl', '6839.57', 27),
(150, 2, 'Carbonated Water - Peach', '3831.01', 48),
(151, 20, 'formal suit', '5745.20', 32),
(152, 12, 'Curry Paste - Madras', '6192.32', 29),
(153, 14, 'superstar', '5.83', 50),
(154, 12, 'doll', '82.23', 51),
(155, 5, 'inspirational quotes', '87.17', 50);

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

CREATE TABLE `regions` (
  `REGION_ID` decimal(5,0) NOT NULL,
  `REGION_NAME` varchar(25) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`REGION_ID`, `REGION_NAME`) VALUES
('1', 'Europe\r'),
('2', 'Americas\r'),
('3', 'Asia\r'),
('4', 'Middle East and Africa\r');

-- --------------------------------------------------------

--
-- Table structure for table `trans`
--

CREATE TABLE `trans` (
  `ac_type` varchar(3) NOT NULL,
  `ac_no` int(4) NOT NULL,
  `tdate` date NOT NULL,
  `counter` int(2) DEFAULT NULL,
  `amount` float(10,2) DEFAULT NULL,
  `description` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trans`
--

INSERT INTO `trans` (`ac_type`, `ac_no`, `tdate`, `counter`, `amount`, `description`) VALUES
('Nom', 7384, '2017-10-03', 44, 445.20, 'donec pharetra magna vestibulu'),
('Nom', 7385, '2018-01-15', 33, 131.11, 'congue eget semper rutrum null'),
('Nom', 7388, '2018-01-26', 14, 323.30, 'aenean lectus pellentesque ege'),
('Nom', 7389, '2018-01-26', 26, 856.76, 'dui maecenas tristique est et '),
('Nom', 7392, '2017-12-09', 46, 233.67, 'scelerisque quam turpis adipis'),
('Nom', 7398, '2017-07-03', 12, 230.06, 'ante ipsum primis in faucibus '),
('Nom', 7399, '2017-11-23', 33, 183.10, 'dolor quis odio consequat vari'),
('Nom', 7402, '2017-10-24', 48, 246.07, 'eget nunc donec quis orci eget'),
('Nom', 7404, '2017-11-02', 39, 993.04, 'orci luctus et ultrices posuer'),
('Nom', 7407, '2017-09-10', 28, 605.70, 'duis consequat dui nec nisi vo'),
('Nom', 7413, '2018-02-07', 2, 501.06, 'justo lacinia eget tincidunt e'),
('Nom', 7414, '2017-06-08', 8, 159.34, 'lorem ipsum dolor sit amet con'),
('Nom', 7417, '2018-01-14', 27, 824.42, 'volutpat convallis morbi odio '),
('Nom', 7420, '2017-10-21', 17, 663.80, 'volutpat quam pede lobortis li'),
('Nom', 7421, '2018-03-13', 16, 125.30, 'ut odio cras mi pede malesuada'),
('Nom', 7425, '2018-02-06', 23, 234.57, 'posuere cubilia curae duis fau'),
('Nom', 7428, '2017-12-14', 23, 201.39, 'erat nulla tempus vivamus in f'),
('Nom', 7430, '2018-03-05', 36, 323.82, 'mi nulla ac enim in tempor tur'),
('Per', 7380, '2017-08-08', 2, 546.45, 'ullamcorper augue a suscipit n'),
('per', 7381, '2017-07-20', 25, 606.81, 'quis tortor id nulla ultrices '),
('per', 7386, '2017-07-10', 4, 415.49, 'id massa id nisl venenatis lac'),
('per', 7387, '2017-08-02', 13, 593.59, 'maecenas leo odio condimentum '),
('Per', 7391, '2017-07-08', 16, 228.23, 'ligula vehicula consequat morb'),
('Per', 7393, '2017-09-29', 34, 429.99, 'habitasse platea dictumst maec'),
('Per', 7394, '2018-04-13', 35, 249.03, 'cum sociis natoque penatibus e'),
('Per', 7395, '2018-03-01', 6, 424.82, 'in est risus auctor sed tristi'),
('Per', 7396, '2018-05-06', 36, 164.93, 'luctus cum sociis natoque pena'),
('Per', 7400, '2017-12-16', 40, 894.07, 'nulla ut erat id mauris vulput'),
('Per', 7408, '2017-11-27', 17, 536.71, 'id consequat in consequat ut n'),
('Per', 7409, '2017-10-19', 49, 519.56, 'quis augue luctus tincidunt nu'),
('Per', 7410, '2018-01-06', 37, 265.69, 'sed interdum venenatis turpis '),
('Per', 7411, '2017-08-03', 46, 600.38, 'massa volutpat convallis morbi'),
('Per', 7412, '2017-11-04', 19, 197.90, 'nascetur ridiculus mus etiam v'),
('Per', 7415, '2017-05-18', 7, 242.84, 'amet eros suspendisse accumsan'),
('Per', 7418, '2017-06-08', 20, 321.81, 'justo eu massa donec dapibus d'),
('Per', 7419, '2017-06-28', 22, 816.50, 'tellus nisi eu orci mauris lac'),
('Per', 7426, '2017-09-17', 13, 471.68, 'in magna bibendum imperdiet nu'),
('Per', 7429, '2018-04-15', 14, 834.35, 'congue risus semper porta volu'),
('Rea', 7382, '2017-11-02', 1, 723.27, 'varius integer ac leo pellente'),
('Rea', 7390, '2017-08-10', 11, 632.21, 'platea dictumst maecenas ut ma'),
('Rea', 7397, '2017-06-05', 24, 464.27, 'eleifend donec ut dolor morbi '),
('Rea', 7401, '2018-02-18', 20, 109.62, 'massa tempor convallis nulla n'),
('Rea', 7403, '2017-10-20', 17, 371.70, 'sapien in sapien iaculis congu'),
('Rea', 7405, '2017-07-16', 4, 783.85, 'cras mi pede malesuada in impe'),
('Rea', 7406, '2017-10-05', 49, 123.33, 'pede lobortis ligula sit amet '),
('Rea', 7416, '2017-06-23', 46, 555.51, 'lacinia sapien quis libero nul'),
('Rea', 7422, '2018-01-02', 25, 309.22, 'neque vestibulum eget vulputat'),
('Rea', 7423, '2017-08-31', 31, 523.86, 'porta volutpat quam pede lobor'),
('Rea', 7424, '2017-10-08', 41, 205.02, 'posuere cubilia curae mauris v'),
('Rea', 7427, '2018-02-16', 7, 818.27, 'rutrum rutrum neque aenean auc');

-- --------------------------------------------------------

--
-- Structure for view `d6`
--
DROP TABLE IF EXISTS `d6`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `d6`  AS  (select `employees`.`FIRST_NAME` AS `first_name`,`employees`.`LAST_NAME` AS `last_name`,`employees`.`SALARY` AS `salary` from `employees` where (`employees`.`DEPARTMENT_ID` in (select `departments`.`DEPARTMENT_ID` from `departments` where (`departments`.`DEPARTMENT_NAME` like 'IT%')) and (`employees`.`SALARY` > (select avg(`employees`.`SALARY`) from `employees`)))) ;

-- --------------------------------------------------------

--
-- Structure for view `d7`
--
DROP TABLE IF EXISTS `d7`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `d7`  AS  select `employees`.`FIRST_NAME` AS `first_name`,`employees`.`LAST_NAME` AS `last_name`,`employees`.`SALARY` AS `salary` from `employees` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ac_mast`
--
ALTER TABLE `ac_mast`
  ADD PRIMARY KEY (`ac_type`,`ac_no`),
  ADD KEY `cust_no` (`cust_no`);

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`bill_id`),
  ADD KEY `cust_id` (`cust_id`),
  ADD KEY `cart_id` (`cart_id`),
  ADD KEY `payment_id` (`payment_id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brand_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`COUNTRY_ID`),
  ADD KEY `COUNTR_REG_FK` (`REGION_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `cust_mast`
--
ALTER TABLE `cust_mast`
  ADD PRIMARY KEY (`cust_no`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`DEPARTMENT_ID`),
  ADD KEY `DEPT_MGR_FK` (`MANAGER_ID`),
  ADD KEY `DEPT_LOCATION_IX` (`LOCATION_ID`);

--
-- Indexes for table `dept`
--
ALTER TABLE `dept`
  ADD PRIMARY KEY (`dno`);

--
-- Indexes for table `emp`
--
ALTER TABLE `emp`
  ADD PRIMARY KEY (`emp_no`),
  ADD KEY `emp_name` (`name`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`EMPLOYEE_ID`),
  ADD UNIQUE KEY `EMP_EMAIL_UK` (`EMAIL`),
  ADD KEY `EMP_DEPARTMENT_IX` (`DEPARTMENT_ID`),
  ADD KEY `EMP_JOB_IX` (`JOB_ID`),
  ADD KEY `EMP_MANAGER_IX` (`MANAGER_ID`),
  ADD KEY `EMP_NAME_IX` (`LAST_NAME`,`FIRST_NAME`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`JOB_ID`);

--
-- Indexes for table `job_history`
--
ALTER TABLE `job_history`
  ADD PRIMARY KEY (`EMPLOYEE_ID`,`START_DATE`),
  ADD KEY `JHIST_DEPARTMENT_IX` (`DEPARTMENT_ID`),
  ADD KEY `JHIST_EMPLOYEE_IX` (`EMPLOYEE_ID`),
  ADD KEY `JHIST_JOB_IX` (`JOB_ID`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`LOCATION_ID`),
  ADD KEY `LOC_CITY_IX` (`CITY`),
  ADD KEY `LOC_COUNTRY_IX` (`COUNTRY_ID`),
  ADD KEY `LOC_STATE_PROVINCE_IX` (`STATE_PROVINCE`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `brand_id` (`brand_id`);

--
-- Indexes for table `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`REGION_ID`),
  ADD UNIQUE KEY `sss` (`REGION_NAME`);

--
-- Indexes for table `trans`
--
ALTER TABLE `trans`
  ADD PRIMARY KEY (`ac_type`,`ac_no`,`tdate`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ac_mast`
--
ALTER TABLE `ac_mast`
  ADD CONSTRAINT `ac_mast_ibfk_1` FOREIGN KEY (`cust_no`) REFERENCES `cust_mast` (`cust_no`);

--
-- Constraints for table `bill`
--
ALTER TABLE `bill`
  ADD CONSTRAINT `bill_ibfk_1` FOREIGN KEY (`cust_id`) REFERENCES `customer` (`cust_id`),
  ADD CONSTRAINT `bill_ibfk_2` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`cart_id`),
  ADD CONSTRAINT `bill_ibfk_3` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`payment_id`);

--
-- Constraints for table `brand`
--
ALTER TABLE `brand`
  ADD CONSTRAINT `brand_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`brand_id`) REFERENCES `brand` (`brand_id`);

--
-- Constraints for table `trans`
--
ALTER TABLE `trans`
  ADD CONSTRAINT `trans_ibfk_1` FOREIGN KEY (`ac_type`,`ac_no`) REFERENCES `ac_mast` (`ac_type`, `ac_no`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

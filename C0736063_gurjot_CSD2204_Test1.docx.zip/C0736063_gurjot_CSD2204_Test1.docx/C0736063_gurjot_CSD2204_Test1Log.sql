MariaDB [csd2204s18]> create table movie
    -> ( id integer(2),
    -> title varchar(20),
    -> director varchar(20),
    -> year integer(4),
    -> length_minutes integer(3),
    -> BOcollection float(1,9)
    -> );
ERROR 1427 (42000): For float(M,D), double(M,D) or decimal(M,D), M must be >= D (column 'BOcollection').
MariaDB [csd2204s18]> create table movie
    -> ( id integer(2),
    -> title varchar(20),
    -> director varchar(20),
    -> year integer(4),
    -> length_minutes integer(3),
    -> BOcollection double(1,9)
    -> );
ERROR 1427 (42000): For float(M,D), double(M,D) or decimal(M,D), M must be >= D (column 'BOcollection').
MariaDB [csd2204s18]> create table movie
    -> ( id integer(2),
    -> title varchar(20),
    -> director varchar(20),
    -> year integer(4),
    -> length_minutes integer(3),
    -> BOcollection float(9,9));
Query OK, 0 rows affected (0.17 sec)

MariaDB [csd2204s18]> insert into values('1','heaven and earth','Maurizio Willock','2004','100','4.36');
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'values('1','heaven and earth','Maurizio Willock','2004','100','4.36')' at line 1
MariaDB [csd2204s18]> insert into movie values('1','heaven and earth','Maurizio Willock','2004','100','4.36');
Query OK, 1 row affected, 1 warning (0.09 sec)

MariaDB [csd2204s18]> insert into movie values('2','the UFO incident','Dillon Dillimore','2008','49','5.46');
Query OK, 1 row affected, 1 warning (0.08 sec)

MariaDB [csd2204s18]> insert into movie values('3','gambit','Carri Garrals','2007','100','53.48');
Query OK, 1 row affected, 1 warning (0.06 sec)

MariaDB [csd2204s18]> insert into movie values('4','against the sun','Stacey Rives','2007','91','48.68');
Query OK, 1 row affected, 1 warning (0.09 sec)

MariaDB [csd2204s18]> insert into movie values('5','room for one more','Coreen Friedlos','2007','80','3.03');
Query OK, 1 row affected, 1 warning (0.06 sec)

MariaDB [csd2204s18]> insert into movie values('6','paris is burning','Carri Garrals','1995','50','26.55');
Query OK, 1 row affected, 1 warning (0.05 sec)

MariaDB [csd2204s18]> insert into movie values('7','cars','John Lasseter','2003','14','77.02');
Query OK, 1 row affected, 1 warning (0.06 sec)

MariaDB [csd2204s18]> insert into movie values('8','invaders from mars','Carri Garrals','2007','50','81.73');
Query OK, 1 row affected, 1 warning (0.08 sec)

MariaDB [csd2204s18]> insert into movie values('9','train','Andrew Stanton','2004','71','81.1');
Query OK, 1 row affected, 1 warning (0.05 sec)

MariaDB [csd2204s18]> insert into movie values('10','buried alive','Dillon Dillimore','2009','100','2.36');
Query OK, 1 row affected, 1 warning (0.05 sec)

MariaDB [csd2204s18]> select *from movie;
+------+--------------------+------------------+------+----------------+--------------+
| id   | title              | director         | year | length_minutes | BOcollection |
+------+--------------------+------------------+------+----------------+--------------+
|    1 | heaven and earth   | Maurizio Willock | 2004 |            100 |  1.000000000 |
|    2 | the UFO incident   | Dillon Dillimore | 2008 |             49 |  1.000000000 |
|    3 | gambit             | Carri Garrals    | 2007 |            100 |  1.000000000 |
|    4 | against the sun    | Stacey Rives     | 2007 |             91 |  1.000000000 |
|    5 | room for one more  | Coreen Friedlos  | 2007 |             80 |  1.000000000 |
|    6 | paris is burning   | Carri Garrals    | 1995 |             50 |  1.000000000 |
|    7 | cars               | John Lasseter    | 2003 |             14 |  1.000000000 |
|    8 | invaders from mars | Carri Garrals    | 2007 |             50 |  1.000000000 |
|    9 | train              | Andrew Stanton   | 2004 |             71 |  1.000000000 |
|   10 | buried alive       | Dillon Dillimore | 2009 |            100 |  1.000000000 |
+------+--------------------+------------------+------+----------------+--------------+
10 rows in set (0.00 sec)

MariaDB [csd2204s18]> update movie column BOcollection double (9,9);
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'column BOcollection double (9,9)' at line 1
MariaDB [csd2204s18]> select title,diector from movie;
ERROR 1054 (42S22): Unknown column 'diector' in 'field list'
MariaDB [csd2204s18]> select title,director from movie;
+--------------------+------------------+
| title              | director         |
+--------------------+------------------+
| heaven and earth   | Maurizio Willock |
| the UFO incident   | Dillon Dillimore |
| gambit             | Carri Garrals    |
| against the sun    | Stacey Rives     |
| room for one more  | Coreen Friedlos  |
| paris is burning   | Carri Garrals    |
| cars               | John Lasseter    |
| invaders from mars | Carri Garrals    |
| train              | Andrew Stanton   |
| buried alive       | Dillon Dillimore |
+--------------------+------------------+
10 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from movie where id ='6';
+------+------------------+---------------+------+----------------+--------------+
| id   | title            | director      | year | length_minutes | BOcollection |
+------+------------------+---------------+------+----------------+--------------+
|    6 | paris is burning | Carri Garrals | 1995 |             50 |  1.000000000 |
+------+------------------+---------------+------+----------------+--------------+
1 row in set (0.00 sec)

MariaDB [csd2204s18]> select title from movie where director='__r%';
Empty set (0.00 sec)

MariaDB [csd2204s18]> select title from movie where director like'__r%';
+--------------------+
| title              |
+--------------------+
| gambit             |
| room for one more  |
| paris is burning   |
| invaders from mars |
+--------------------+
4 rows in set (0.00 sec)

MariaDB [csd2204s18]> select * from movie where year>2000 && year<2008;
+------+--------------------+------------------+------+----------------+--------------+
| id   | title              | director         | year | length_minutes | BOcollection |
+------+--------------------+------------------+------+----------------+--------------+
|    1 | heaven and earth   | Maurizio Willock | 2004 |            100 |  1.000000000 |
|    3 | gambit             | Carri Garrals    | 2007 |            100 |  1.000000000 |
|    4 | against the sun    | Stacey Rives     | 2007 |             91 |  1.000000000 |
|    5 | room for one more  | Coreen Friedlos  | 2007 |             80 |  1.000000000 |
|    7 | cars               | John Lasseter    | 2003 |             14 |  1.000000000 |
|    8 | invaders from mars | Carri Garrals    | 2007 |             50 |  1.000000000 |
|    9 | train              | Andrew Stanton   | 2004 |             71 |  1.000000000 |
+------+--------------------+------------------+------+----------------+--------------+
7 rows in set (0.00 sec)

MariaDB [csd2204s18]> select title,year from movie limit 5;
+-------------------+------+
| title             | year |
+-------------------+------+
| heaven and earth  | 2004 |
| the UFO incident  | 2008 |
| gambit            | 2007 |
| against the sun   | 2007 |
| room for one more | 2007 |
+-------------------+------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> select  title , director from movie where director!='Carri Garrals';
+-------------------+------------------+
| title             | director         |
+-------------------+------------------+
| heaven and earth  | Maurizio Willock |
| the UFO incident  | Dillon Dillimore |
| against the sun   | Stacey Rives     |
| room for one more | Coreen Friedlos  |
| cars              | John Lasseter    |
| train             | Andrew Stanton   |
| buried alive      | Dillon Dillimore |
+-------------------+------------------+
7 rows in set (0.00 sec)

MariaDB [csd2204s18]> select  distinct(director) from movie where director>=A; 
ERROR 1054 (42S22): Unknown column 'A' in 'where clause'
MariaDB [csd2204s18]> select  distinct(director) from movie where director>='A'; 
+------------------+
| director         |
+------------------+
| Maurizio Willock |
| Dillon Dillimore |
| Carri Garrals    |
| Stacey Rives     |
| Coreen Friedlos  |
| John Lasseter    |
| Andrew Stanton   |
+------------------+
7 rows in set (0.00 sec)

MariaDB [csd2204s18]> select  distinct(director) from movie where director like A asc; 
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'asc' at line 1
MariaDB [csd2204s18]> select  distinct(director) from movie where director like 'A' asc; 
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'asc' at line 1
MariaDB [csd2204s18]> select  distinct(director) from movie where director like '^[A-z]'; 
Empty set (0.00 sec)

MariaDB [csd2204s18]> select  distinct(director) from movie where director like '^[A-z]%'; 
Empty set (0.00 sec)

MariaDB [csd2204s18]> select  distinct(director) from movie order by tittle asc; 
ERROR 1054 (42S22): Unknown column 'tittle' in 'order clause'
MariaDB [csd2204s18]> select  distinct(director) from movie order by title asc; 
+------------------+
| director         |
+------------------+
| Stacey Rives     |
| John Lasseter    |
| Carri Garrals    |
| Maurizio Willock |
| Coreen Friedlos  |
| Dillon Dillimore |
| Andrew Stanton   |
+------------------+
7 rows in set (0.00 sec)

MariaDB [csd2204s18]> select distinct(title) from movie where year>2003 && year<2010; 
+--------------------+
| title              |
+--------------------+
| heaven and earth   |
| the UFO incident   |
| gambit             |
| against the sun    |
| room for one more  |
| invaders from mars |
| train              |
| buried alive       |
+--------------------+
8 rows in set (0.00 sec)

MariaDB [csd2204s18]> select distinct(title) from movie where year>2003 && year<2010 limit 4; 
+------------------+
| title            |
+------------------+
| heaven and earth |
| the UFO incident |
| gambit           |
| against the sun  |
+------------------+
4 rows in set (0.00 sec)

MariaDB [csd2204s18]> select distinct(title) from movie where year>2006 && year<2010 limit 4; 
+-------------------+
| title             |
+-------------------+
| the UFO incident  |
| gambit            |
| against the sun   |
| room for one more |
+-------------------+
4 rows in set (0.00 sec)

MariaDB [csd2204s18]> select distinct(title) from movie where year=2009 && year>2006 && year<2010 limit 4; 
+--------------+
| title        |
+--------------+
| buried alive |
+--------------+
1 row in set (0.00 sec)

MariaDB [csd2204s18]> select count(BOcollection)"releases" from movie; 
+----------+
| releases |
+----------+
|       10 |
+----------+
1 row in set (0.00 sec)

MariaDB [csd2204s18]> select count(*)"releases" from movie; 
+----------+
| releases |
+----------+
|       10 |
+----------+
1 row in set (0.00 sec)

MariaDB [csd2204s18]> select avg(length_minutes)from movie;
+---------------------+
| avg(length_minutes) |
+---------------------+
|             70.5000 |
+---------------------+
1 row in set (0.03 sec)

MariaDB [csd2204s18]> select director from movie order by BOcollection desc ;
+------------------+
| director         |
+------------------+
| Maurizio Willock |
| Andrew Stanton   |
| Carri Garrals    |
| John Lasseter    |
| Carri Garrals    |
| Coreen Friedlos  |
| Stacey Rives     |
| Carri Garrals    |
| Dillon Dillimore |
| Dillon Dillimore |
+------------------+
10 rows in set (0.00 sec)

MariaDB [csd2204s18]> select director from movie order by BOcollection asc ;
+------------------+
| director         |
+------------------+
| Maurizio Willock |
| Andrew Stanton   |
| Carri Garrals    |
| John Lasseter    |
| Carri Garrals    |
| Coreen Friedlos  |
| Stacey Rives     |
| Carri Garrals    |
| Dillon Dillimore |
| Dillon Dillimore |
+------------------+
10 rows in set (0.00 sec)

MariaDB [csd2204s18]> select director from movie where title='invaders of mars';
Empty set (0.00 sec)

MariaDB [csd2204s18]> select director from movie where title=invaders of mars;
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'of mars' at line 1
MariaDB [csd2204s18]> select director from movie where id = '8';
+---------------+
| director      |
+---------------+
| Carri Garrals |
+---------------+
1 row in set (0.00 sec)

MariaDB [csd2204s18]> select BOcollection from movie having director='Carrie Garrals' && year<2000;
ERROR 1054 (42S22): Unknown column 'director' in 'having clause'
MariaDB [csd2204s18]> select BOcollection from movie where director='Carrie Garrals' && year<2000;
Empty set (0.03 sec)

MariaDB [csd2204s18]> select BOcollection from movie where year<2000;
+--------------+
| BOcollection |
+--------------+
|  1.000000000 |
+--------------+
1 row in set (0.00 sec)

MariaDB [csd2204s18]> select count(*)"releases" from movie group by year;
+----------+
| releases |
+----------+
|        1 |
|        1 |
|        2 |
|        4 |
|        1 |
|        1 |
+----------+
6 rows in set (0.02 sec)

MariaDB [csd2204s18]> select title ,year from movie order by year limit 5;
+------------------+------+
| title            | year |
+------------------+------+
| paris is burning | 1995 |
| cars             | 2003 |
| heaven and earth | 2004 |
| train            | 2004 |
| gambit           | 2007 |
+------------------+------+
5 rows in set (0.00 sec)

MariaDB [csd2204s18]> select BOcollection from movie where director ="Carri Garrels"&& year<2000;
Empty set (0.00 sec)

MariaDB [csd2204s18]> select * from movie;
+------+--------------------+------------------+------+----------------+--------------+
| id   | title              | director         | year | length_minutes | BOcollection |
+------+--------------------+------------------+------+----------------+--------------+
|    1 | heaven and earth   | Maurizio Willock | 2004 |            100 |  1.000000000 |
|    2 | the UFO incident   | Dillon Dillimore | 2008 |             49 |  1.000000000 |
|    3 | gambit             | Carri Garrals    | 2007 |            100 |  1.000000000 |
|    4 | against the sun    | Stacey Rives     | 2007 |             91 |  1.000000000 |
|    5 | room for one more  | Coreen Friedlos  | 2007 |             80 |  1.000000000 |
|    6 | paris is burning   | Carri Garrals    | 1995 |             50 |  1.000000000 |
|    7 | cars               | John Lasseter    | 2003 |             14 |  1.000000000 |
|    8 | invaders from mars | Carri Garrals    | 2007 |             50 |  1.000000000 |
|    9 | train              | Andrew Stanton   | 2004 |             71 |  1.000000000 |
|   10 | buried alive       | Dillon Dillimore | 2009 |            100 |  1.000000000 |
+------+--------------------+------------------+------+----------------+--------------+
10 rows in set (0.00 sec)

MariaDB [csd2204s18]> select BOcollection from movie where director ="Carri Garrals"&& year<2000;
+--------------+
| BOcollection |
+--------------+
|  1.000000000 |
+--------------+
1 row in set (0.02 sec)

MariaDB [csd2204s18]> alter table movie length minutes integer(34) where title ='cars';
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'minutes integer(34) where title ='cars'' at line 1
MariaDB [csd2204s18]> alter table movie change director(23);
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '(23)' at line 1
MariaDB [csd2204s18]> alter table movie change director varchar(23);
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'varchar(23)' at line 1
MariaDB [csd2204s18]> alter table movie change column  director varchar(23);
ERROR 1064 (42000): You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'varchar(23)' at line 1
MariaDB [csd2204s18]> exit;
